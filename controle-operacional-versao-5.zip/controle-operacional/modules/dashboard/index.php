<?php
declare(strict_types=1);

use Controle\Auth\Auth;

$base = APP_BASE_PATH;
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
$user = Auth::user();

$modules = [
    ['code' => 'compras', 'label' => 'Compras', 'url' => '/compras'],
    ['code' => 'organograma', 'label' => 'Organograma', 'url' => '/organograma'],
    ['code' => 'justificativa-he', 'label' => 'Justificativa HE', 'url' => '/justificativa-he'],
    ['code' => 'pagamentos', 'label' => 'Pagamentos', 'url' => '/pagamentos'],
    ['code' => 'solicitacoes', 'label' => 'Solicitações', 'url' => '/solicitacoes'],
    ['code' => 'plano-de-acao', 'label' => 'Plano de Ação', 'url' => '/plano-de-acao'],
    ['code' => 'atividades', 'label' => 'Atividades', 'url' => '/atividades'],
    ['code' => 'adm-compras', 'label' => 'ADM · Compras', 'url' => '/adm/compras'],
    ['code' => 'adm-organograma', 'label' => 'ADM · Organograma', 'url' => '/adm/organograma'],
    ['code' => 'adm-solicitacoes', 'label' => 'ADM · Solicitações', 'url' => '/adm/solicitacoes'],
];

$visibleModules = array_values(array_filter(
    $modules,
    fn(array $m): bool => Auth::can($m['code'], 'visualizar')
));
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= $base ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <h1><?= htmlspecialchars(APP_NAME) ?></h1>
            <p class="muted">
                <?= htmlspecialchars($user['nome'] ?? '') ?>
                · <?= htmlspecialchars(ucfirst($user['perfil'] ?? '')) ?>
            </p>
        </div>

        <div class="top-actions">
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
            <?php if (Auth::isAdmin()): ?>
                <a href="<?= $base ?>/adm/usuarios">Usuários</a>
            <?php endif; ?>
            <a href="<?= $base ?>/logout">Sair</a>
        </div>
    </div>

    <?php if (!$visibleModules): ?>
        <div class="alert">Nenhum módulo foi liberado para este usuário.</div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($visibleModules as $module): ?>
                <a class="card" href="<?= $base . $module['url'] ?>">
                    <strong><?= htmlspecialchars($module['label']) ?></strong>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
<script src="<?= $base ?>/assets/js/app.js"></script>
</body>
</html>
