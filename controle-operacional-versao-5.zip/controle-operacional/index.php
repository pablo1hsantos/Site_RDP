<?php
declare(strict_types=1);

require __DIR__ . '/src/Core/bootstrap.php';

use Controle\Core\Router;

$router = new Router(APP_ENV, APP_BASE_PATH);

$router->dispatch();
