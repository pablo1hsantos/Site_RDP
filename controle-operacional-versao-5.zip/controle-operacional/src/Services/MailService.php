<?php
declare(strict_types=1);

namespace Controle\Services;

use RuntimeException;

final class MailService
{
    public static function sendInvite(
        string $recipientEmail,
        string $recipientName,
        string $activationUrl,
        string $expiresAt
    ): void {
        $subject = 'Você foi convidado para o Controle Operacional';

        $safeName = htmlspecialchars($recipientName, ENT_QUOTES, 'UTF-8');
        $safeUrl = htmlspecialchars($activationUrl, ENT_QUOTES, 'UTF-8');
        $safeExpires = htmlspecialchars($expiresAt, ENT_QUOTES, 'UTF-8');

        $html = <<<HTML
<!doctype html>
<html lang="pt-BR">
<body style="margin:0;padding:0;background:#f4f6f8;font-family:Arial,Helvetica,sans-serif;color:#1f2937;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f6f8;padding:24px 12px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;">
          <tr>
            <td style="padding:32px;">
              <h1 style="font-size:24px;margin:0 0 16px;">Controle Operacional</h1>
              <p style="font-size:16px;line-height:1.6;margin:0 0 16px;">Olá, {$safeName}.</p>
              <p style="font-size:16px;line-height:1.6;margin:0 0 24px;">
                Você foi convidado para acessar o Controle Operacional.
                Clique no botão abaixo para definir sua senha e ativar sua conta.
              </p>
              <p style="margin:0 0 24px;">
                <a href="{$safeUrl}"
                   style="display:inline-block;background:#1f2937;color:#ffffff;text-decoration:none;font-weight:700;padding:13px 20px;border-radius:8px;">
                  Ativar meu acesso
                </a>
              </p>
              <p style="font-size:14px;line-height:1.6;color:#64748b;margin:0 0 12px;">
                Este convite é válido até {$safeExpires}.
              </p>
              <p style="font-size:14px;line-height:1.6;color:#64748b;margin:0;">
                Se você não esperava receber este convite, ignore esta mensagem.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;

        $text = "Olá, {$recipientName}.\n\n"
              . "Você foi convidado para acessar o Controle Operacional.\n"
              . "Ative seu acesso e defina sua senha em:\n{$activationUrl}\n\n"
              . "Este convite é válido até {$expiresAt}.\n";

        self::send($recipientEmail, $recipientName, $subject, $html, $text);
    }

    public static function send(
        string $recipientEmail,
        string $recipientName,
        string $subject,
        string $htmlBody,
        string $textBody
    ): void {
        $configFile = APP_ROOT . '/config/mail.php';

        if (!is_file($configFile)) {
            throw new RuntimeException('Configuração de e-mail ainda não criada.');
        }

        $config = require $configFile;

        foreach (['host', 'port', 'username', 'password', 'from_email', 'from_name'] as $key) {
            if (empty($config[$key]) || str_contains((string)$config[$key], 'SENHA_DO_EMAIL_AQUI')) {
                throw new RuntimeException('Configuração SMTP incompleta.');
            }
        }

        $transport = ($config['encryption'] ?? 'ssl') === 'ssl' ? 'ssl://' : '';
        $remote = $transport . $config['host'] . ':' . (int)$config['port'];

        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false,
                'peer_name' => $config['host'],
            ],
        ]);

        $socket = @stream_socket_client(
            $remote,
            $errno,
            $errstr,
            (int)($config['timeout'] ?? 20),
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!$socket) {
            throw new RuntimeException('Não foi possível conectar ao servidor SMTP.');
        }

        stream_set_timeout($socket, (int)($config['timeout'] ?? 20));

        try {
            self::expect($socket, [220]);

            self::command($socket, 'EHLO ' . ($_SERVER['SERVER_NAME'] ?? 'portalrdp.online'), [250]);

            self::command($socket, 'AUTH LOGIN', [334]);
            self::command($socket, base64_encode((string)$config['username']), [334], false);
            self::command($socket, base64_encode((string)$config['password']), [235], false);

            self::command($socket, 'MAIL FROM:<' . $config['from_email'] . '>', [250]);
            self::command($socket, 'RCPT TO:<' . $recipientEmail . '>', [250, 251]);
            self::command($socket, 'DATA', [354]);

            $boundary = '=_controle_' . bin2hex(random_bytes(12));

            $headers = [
                'Date: ' . date(DATE_RFC2822),
                'From: ' . self::encodeHeader((string)$config['from_name']) . ' <' . $config['from_email'] . '>',
                'To: ' . self::encodeHeader($recipientName) . ' <' . $recipientEmail . '>',
                'Subject: ' . self::encodeHeader($subject),
                'Message-ID: <' . bin2hex(random_bytes(12)) . '@portalrdp.online>',
                'MIME-Version: 1.0',
                'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
            ];

            $message = implode("\r\n", $headers) . "\r\n\r\n";
            $message .= '--' . $boundary . "\r\n";
            $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= self::normalizeBody($textBody) . "\r\n\r\n";
            $message .= '--' . $boundary . "\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= self::normalizeBody($htmlBody) . "\r\n\r\n";
            $message .= '--' . $boundary . "--\r\n";

            // SMTP dot-stuffing
            $message = preg_replace('/(?m)^\./', '..', $message) ?? $message;

            fwrite($socket, $message . "\r\n.\r\n");
            self::expect($socket, [250]);

            self::command($socket, 'QUIT', [221]);
        } finally {
            fclose($socket);
        }
    }

    private static function command($socket, string $command, array $expected, bool $loggable = true): string
    {
        fwrite($socket, $command . "\r\n");
        return self::expect($socket, $expected);
    }

    private static function expect($socket, array $expected): string
    {
        $response = '';

        while (($line = fgets($socket, 515)) !== false) {
            $response .= $line;

            if (preg_match('/^(\d{3})([ -])/', $line, $matches)) {
                $code = (int)$matches[1];
                $separator = $matches[2];

                if ($separator === ' ') {
                    if (!in_array($code, $expected, true)) {
                        throw new RuntimeException('Servidor SMTP recusou a operação.');
                    }

                    return $response;
                }
            }
        }

        throw new RuntimeException('Resposta SMTP incompleta.');
    }

    private static function encodeHeader(string $value): string
    {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    private static function normalizeBody(string $body): string
    {
        return str_replace(["\r\n", "\r"], "\n", $body);
    }
}
