<?php
declare(strict_types=1);

namespace Controle\Services;

use Controle\Core\Database;
use InvalidArgumentException;
use PDOException;

final class UserService
{
    public static function list(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT *
             FROM usuarios
             ORDER BY nome'
        )->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE id = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $id]);

        $user = $stmt->fetch();

        return $user ?: null;
    }

    public static function createPendingAndInvite(array $data): array
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');

        self::validateBase($nome, $email, $perfil);

        $token = self::generateInviteToken();
        $temporaryPassword = bin2hex(random_bytes(32));

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO usuarios
                (
                    nome, email, senha_hash, perfil, ativo,
                    primeiro_acesso_pendente,
                    codigo_ativacao_hash,
                    codigo_ativacao_expira,
                    convite_token_hash,
                    convite_enviado_em,
                    ativado_em,
                    criado_em, atualizado_em
                )
                VALUES
                (
                    :nome, :email, :senha_hash, :perfil, :ativo,
                    1,
                    NULL,
                    DATE_ADD(NOW(), INTERVAL 72 HOUR),
                    :token_hash,
                    NULL,
                    NULL,
                    NOW(), NOW()
                )'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'senha_hash' => password_hash($temporaryPassword, PASSWORD_DEFAULT),
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'token_hash' => hash('sha256', $token),
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }

        $id = (int)$pdo->lastInsertId();

        try {
            self::sendInvite($id, $token);
        } catch (\Throwable $e) {
            return [
                'id' => $id,
                'sent' => false,
                'error' => $e->getMessage(),
            ];
        }

        return [
            'id' => $id,
            'sent' => true,
            'error' => null,
        ];
    }

    public static function resendInvite(int $id): void
    {
        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!(bool)($user['primeiro_acesso_pendente'] ?? false)) {
            throw new InvalidArgumentException('Este usuário já concluiu o primeiro acesso.');
        }

        if (!(bool)$user['ativo']) {
            throw new InvalidArgumentException('Ative o usuário antes de reenviar o convite.');
        }

        $token = self::generateInviteToken();
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET convite_token_hash = :token_hash,
                 codigo_ativacao_expira = DATE_ADD(NOW(), INTERVAL 72 HOUR),
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'token_hash' => hash('sha256', $token),
            'id' => $id,
        ]);

        self::sendInvite($id, $token);
    }

    public static function findPendingByToken(string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
            return null;
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE convite_token_hash = :token_hash
               AND primeiro_acesso_pendente = 1
               AND ativo = 1
             LIMIT 1'
        );

        $stmt->execute([
            'token_hash' => hash('sha256', $token),
        ]);

        $user = $stmt->fetch();

        if (!$user) {
            return null;
        }

        if (
            empty($user['codigo_ativacao_expira']) ||
            strtotime((string)$user['codigo_ativacao_expira']) < time()
        ) {
            return null;
        }

        return $user;
    }

    public static function activateByToken(string $token, string $password): void
    {
        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $user = self::findPendingByToken($token);

        if (!$user) {
            throw new InvalidArgumentException('Convite inválido ou expirado.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :senha_hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 convite_token_hash = NULL,
                 ativado_em = NOW(),
                 atualizado_em = NOW()
             WHERE id = :id
               AND primeiro_acesso_pendente = 1'
        );

        $stmt->execute([
            'senha_hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $user['id'],
        ]);
    }

    public static function update(int $id, array $data): void
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');

        self::validateBase($nome, $email, $perfil);

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'UPDATE usuarios
                 SET nome = :nome,
                     email = :email,
                     perfil = :perfil,
                     ativo = :ativo,
                     atualizado_em = NOW()
                 WHERE id = :id'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'id' => $id,
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }
    }

    public static function resetPassword(int $id, string $password): void
    {
        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 convite_token_hash = NULL,
                 ativado_em = COALESCE(ativado_em, NOW()),
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $id,
        ]);
    }

    public static function modules(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT id, codigo, nome
             FROM modulos
             WHERE ativo = 1
             ORDER BY nome'
        )->fetchAll();
    }

    public static function permissions(int $userId): array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT modulo_id, visualizar, criar, editar, excluir, administrar
             FROM permissoes_usuario
             WHERE usuario_id = :usuario_id'
        );
        $stmt->execute(['usuario_id' => $userId]);

        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['modulo_id']] = $row;
        }

        return $out;
    }

    public static function savePermissions(int $userId, array $permissions): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $del = $pdo->prepare('DELETE FROM permissoes_usuario WHERE usuario_id = :usuario_id');
            $del->execute(['usuario_id' => $userId]);

            $ins = $pdo->prepare(
                'INSERT INTO permissoes_usuario
                (usuario_id, modulo_id, visualizar, criar, editar, excluir, administrar)
                VALUES
                (:usuario_id, :modulo_id, :visualizar, :criar, :editar, :excluir, :administrar)'
            );

            foreach ($permissions as $moduleId => $row) {
                $moduleId = (int)$moduleId;
                if ($moduleId <= 0) {
                    continue;
                }

                $ins->execute([
                    'usuario_id' => $userId,
                    'modulo_id' => $moduleId,
                    'visualizar' => !empty($row['visualizar']) ? 1 : 0,
                    'criar' => !empty($row['criar']) ? 1 : 0,
                    'editar' => !empty($row['editar']) ? 1 : 0,
                    'excluir' => !empty($row['excluir']) ? 1 : 0,
                    'administrar' => !empty($row['administrar']) ? 1 : 0,
                ]);
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function sendInvite(int $id, string $token): void
    {
        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'https';
        $host = $_SERVER['HTTP_HOST'] ?? 'portalrdp.online';
        $activationUrl = $scheme . '://' . $host . APP_BASE_PATH . '/primeiro-acesso?token=' . urlencode($token);

        $expiresAt = date(
            'd/m/Y H:i',
            strtotime('+72 hours')
        );

        MailService::sendInvite(
            (string)$user['email'],
            (string)$user['nome'],
            $activationUrl,
            $expiresAt
        );

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET convite_enviado_em = NOW(),
                 atualizado_em = NOW()
             WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);
    }

    private static function validateBase(string $nome, string $email, string $perfil): void
    {
        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do usuário.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Informe um e-mail válido.');
        }

        if (!in_array($perfil, ['administrador', 'gestor', 'usuario'], true)) {
            throw new InvalidArgumentException('Perfil inválido.');
        }
    }

    private static function generateInviteToken(): string
    {
        return bin2hex(random_bytes(32));
    }
}
