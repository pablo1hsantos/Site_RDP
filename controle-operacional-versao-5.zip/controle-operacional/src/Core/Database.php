<?php
declare(strict_types=1);

namespace Controle\Core;

use PDO;
use PDOException;
use RuntimeException;

final class Database
{
    private static ?PDO $connection = null;

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $all = require APP_ROOT . '/config/database.php';

        if (!isset($all[APP_ENV])) {
            throw new RuntimeException('Configuração de banco não encontrada para o ambiente.');
        }

        $config = $all[APP_ENV];

        if (
            empty($config['database']) ||
            empty($config['username']) ||
            empty($config['password']) ||
            str_starts_with((string)$config['password'], 'COLOQUE_')
        ) {
            throw new RuntimeException('Banco de dados ainda não configurado.');
        }

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $config['host'],
            $config['port'],
            $config['database'],
            $config['charset']
        );

        try {
            self::$connection = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            throw new RuntimeException('Falha ao conectar ao banco de dados.');
        }

        return self::$connection;
    }
}
