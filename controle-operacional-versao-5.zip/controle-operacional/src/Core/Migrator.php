<?php
declare(strict_types=1);

namespace Controle\Core;

use PDO;

final class Migrator
{
    public static function runV4(): void
    {
        $pdo = Database::connection();

        $columns = [
            'primeiro_acesso_pendente' => "
                ALTER TABLE usuarios
                ADD COLUMN primeiro_acesso_pendente TINYINT(1) NOT NULL DEFAULT 0 AFTER ativo
            ",
            'codigo_ativacao_hash' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_hash VARCHAR(255) NULL AFTER primeiro_acesso_pendente
            ",
            'codigo_ativacao_expira' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_expira DATETIME NULL AFTER codigo_ativacao_hash
            ",
        ];

        self::addMissingColumns($pdo, 'usuarios', $columns);
    }

    public static function runV5(): void
    {
        self::runV4();

        $pdo = Database::connection();

        $columns = [
            'convite_token_hash' => "
                ALTER TABLE usuarios
                ADD COLUMN convite_token_hash CHAR(64) NULL AFTER codigo_ativacao_expira
            ",
            'convite_enviado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN convite_enviado_em DATETIME NULL AFTER convite_token_hash
            ",
            'ativado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN ativado_em DATETIME NULL AFTER convite_enviado_em
            ",
        ];

        self::addMissingColumns($pdo, 'usuarios', $columns);
    }

    private static function addMissingColumns(PDO $pdo, string $table, array $columns): void
    {
        foreach ($columns as $column => $sql) {
            if (!self::columnExists($pdo, $table, $column)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = :table_name
               AND COLUMN_NAME = :column_name'
        );

        $stmt->execute([
            'table_name' => $table,
            'column_name' => $column,
        ]);

        return (int)$stmt->fetchColumn() > 0;
    }
}
