# Deploy inicial na HostGator

1. Faça backup do conteúdo atual de `public_html`.
2. Envie o conteúdo deste projeto para uma pasta de teste primeiro.
3. Confirme que `mod_rewrite` funciona.
4. Teste a raiz.
5. Teste `/qa/`.
6. Teste cada rota de módulo.
7. Só depois substitua/integre com o conteúdo oficial de `public_html`.

## Rotas de teste
- /
- /qa/
- /compras
- /qa/compras
- /adm/compras
- /qa/adm/compras

## Observação
Este pacote não contém senhas, IDs de planilhas, chaves do Google ou dados reais.
