# Controle Operacional - Versão 2

## Bancos confirmados

### PROD
- Banco: `pablo718_controle_prod`
- Usuário: `pablo718_controle_prod`

### QA
- Banco: `pablo718_controle_qa`
- Usuário: `pablo718_controle_qa`

## 1. Configurar as senhas

Depois de enviar os arquivos, abra:

`/public_html/config/database.php`

Substitua:

`COLOQUE_A_SENHA_PROD_AQUI`

pela senha do usuário MySQL de produção.

Substitua:

`COLOQUE_A_SENHA_QA_AQUI`

pela senha do usuário MySQL de QA.

Não coloque a senha de um ambiente no outro.

## 2. Criar o administrador em QA primeiro

Abra:

`https://portalrdp.online/qa/setup`

Preencha a senha desejada para o administrador.

Dados pré-preenchidos:
- Nome: Pablo Santos
- E-mail: pablo_santos@gpssa.com.br

Depois teste:

`https://portalrdp.online/qa/login`

## 3. Criar o administrador em produção

Após validar o QA:

`https://portalrdp.online/setup`

Defina a senha do administrador de produção.

Depois acesse:

`https://portalrdp.online/login`

## 4. Segurança do setup

O setup verifica se já existe usuário cadastrado.
Se já existir, a criação inicial é bloqueada.

## 5. Estrutura de permissões

Ações disponíveis:
- visualizar
- criar
- editar
- excluir
- administrar

O administrador tem acesso total automaticamente.

Gestores e usuários terão permissões específicas por módulo nas próximas telas administrativas.
