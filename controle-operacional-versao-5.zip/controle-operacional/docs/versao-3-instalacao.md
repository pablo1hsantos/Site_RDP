# Controle Operacional - Versão 3

## O que muda
- Administração de usuários
- Criar e editar usuários
- Ativar/desativar usuários
- Redefinir senhas
- Perfis Administrador, Gestor e Usuário
- Permissões individuais por módulo
- Ações: visualizar, criar, editar, excluir e administrar

## Importante: database.php

A partir desta versão, o arquivo:

`config/database.php`

não faz parte do pacote ZIP de atualização.

O servidor deve manter o arquivo existente com suas credenciais.

O ZIP contém apenas:

`config/database.example.php`

como modelo.

## Atualização recomendada

1. Faça backup dos arquivos atuais.
2. Extraia a Versão 3.
3. Copie os arquivos e pastas para `/public_html`, permitindo sobrescrever o código.
4. NÃO exclua o arquivo existente `/public_html/config/database.php`.
5. Entre primeiro no QA.
6. Teste `/qa/adm/usuarios`.
7. Crie um usuário de teste e configure permissões.
8. Faça login com o usuário de teste e confirme que só aparecem os módulos liberados.
9. Depois valide PROD.

## Rotas novas
- `/adm/usuarios`
- `/adm/usuarios/novo`
- `/adm/usuarios/editar?id=1`
- `/adm/usuarios/permissoes?id=1`
- `/adm/usuarios/senha?id=1`

No QA, acrescente `/qa` no início.

## Administrador
Administradores possuem acesso total automaticamente.
A matriz de permissões individuais não é necessária para um administrador.

## Gestor e Usuário
Nesta versão, Gestor e Usuário usam permissões individuais por módulo.
O perfil identifica o tipo do usuário; o acesso efetivo é definido pela matriz de permissões.
