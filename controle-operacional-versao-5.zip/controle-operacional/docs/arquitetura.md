# Arquitetura inicial

## Aplicação
- Nome: Controle Operacional
- Domínio: portalrdp.online
- Produção: https://portalrdp.online/
- QA: https://portalrdp.online/qa/

## Estratégia
Há um único código-fonte.

A aplicação detecta o ambiente pela URL:
- `/...` => production
- `/qa/...` => qa

Os dois ambientes usam os mesmos módulos, mas poderão apontar para planilhas,
pastas do Drive e demais configurações diferentes.

## Módulos
- Compras
- Organograma
- Justificativa HE
- Pagamentos
- Solicitações
- Plano de Ação
- Atividades
- ADM / Compras
- ADM / Organograma
- ADM / Solicitações

## Próximas etapas
1. Login e sessão
2. Layout definitivo
3. Perfis e permissões
4. Logs
5. Integração Google
