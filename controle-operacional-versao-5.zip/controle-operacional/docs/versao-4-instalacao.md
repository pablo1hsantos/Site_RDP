# Controle Operacional - Versão 4

## Recurso principal
Primeiro acesso com código temporário.

O administrador não define mais a senha inicial do usuário.

## Fluxo
1. Administrador cria o usuário.
2. Sistema gera um código temporário.
3. Administrador configura as permissões.
4. Usuário acessa `/primeiro-acesso`.
5. Usuário informa e-mail, código e cria a própria senha.
6. Código é invalidado.
7. Usuário passa a usar `/login`.

## Validade
O código expira em 72 horas.

O administrador pode gerar um novo código enquanto o usuário estiver pendente.

## Atualização do banco

Após subir a Versão 4, aplique primeiro no QA:

`https://portalrdp.online/qa/adm/atualizar`

Clique em:

`Aplicar atualização`

Depois faça o mesmo em PROD:

`https://portalrdp.online/adm/atualizar`

A migração é não destrutiva.
Usuários, senhas e permissões existentes permanecem.

## Teste recomendado em QA

1. Aplique `/qa/adm/atualizar`.
2. Abra `/qa/adm/usuarios`.
3. Crie um usuário de teste.
4. Guarde o código mostrado.
5. Configure permissões.
6. Abra uma janela anônima.
7. Entre em `/qa/primeiro-acesso`.
8. Informe o e-mail, código e uma nova senha.
9. Entre em `/qa/login`.
10. Confirme que aparecem somente os módulos autorizados.

## Segurança

O código original não fica salvo em texto no banco.
Somente o hash do código é armazenado.

Depois da ativação, o código é removido.


## Observação sobre sessão
A Versão 4 separa também o cookie de sessão de QA e PROD.
Após atualizar, pode ser necessário fazer login novamente em cada ambiente.
Isso não altera sua senha.

## Ordem exata de instalação
1. Suba e sobrescreva os arquivos da Versão 4.
2. Não altere nem exclua `config/database.php`.
3. Entre novamente no QA se necessário.
4. Abra `/qa/adm/atualizar`.
5. Clique em `Aplicar atualização`.
6. Teste a criação de um usuário pendente.
7. Depois repita `/adm/atualizar` em PROD.
