# Primeiro upload na HostGator

## Ambiente confirmado
- PHP: 8.4.24
- Domínio: portalrdp.online
- Pasta de publicação: `/public_html`
- Produção: https://portalrdp.online/
- QA: https://portalrdp.online/qa/

## Antes de enviar
1. Acesse `/public_html` no Gerenciador de Arquivos da HostGator.
2. Não envie credenciais Google nesta etapa.
3. Envie o ZIP do Controle Operacional para `/public_html`.
4. Extraia o ZIP.
5. Mova o CONTEÚDO da pasta `controle-operacional` para `/public_html`.
6. Confirme que o arquivo `.htaccess` está presente.
7. No Gerenciador de Arquivos, habilite a visualização de arquivos ocultos (dotfiles) se necessário.

## Estrutura esperada em public_html

```text
public_html/
├── .htaccess
├── index.php
├── assets/
├── config/
├── docs/
├── modules/
├── src/
├── storage/
├── README.md
└── CHANGELOG.md
```

## Não deixar assim

```text
public_html/
└── controle-operacional/
    └── index.php
```

Nesse caso o domínio não abriria diretamente o sistema.

## Teste mínimo
Depois do upload, confirmar:

- `/`
- `/compras`
- `/organograma`
- `/justificativa-he`
- `/pagamentos`
- `/solicitacoes`
- `/plano-de-acao`
- `/atividades`
- `/adm/compras`
- `/adm/organograma`
- `/adm/solicitacoes`

E no QA:

- `/qa/`
- `/qa/compras`
- `/qa/adm/compras`

## Se aparecer erro 500
Verificar nesta ordem:
1. `.htaccess`
2. `mod_rewrite`
3. permissões de arquivos/pastas
4. log de erros do PHP no cPanel
5. caminhos dos arquivos em `/public_html`

## Controle de versão sem GitHub
Guardar localmente os pacotes entregues:

- `controle-operacional-v0.1.1.zip`
- `controle-operacional-v0.1.2.zip`
- `controle-operacional-v0.1.3.zip`

O histórico das alterações fica em `CHANGELOG.md`.
