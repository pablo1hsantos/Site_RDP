# Controle Operacional - Versão 5

## Recurso principal
Convite automático por e-mail com link único de ativação.

## SMTP
- Servidor: `mail.portalrdp.online`
- Porta: `465`
- Segurança: SSL/TLS implícito
- Autenticação: obrigatória
- Usuário: `noreply@portalrdp.online`

## 1. Criar config/mail.php

O ZIP não inclui `config/mail.php`.

No servidor, copie:

`config/mail.example.php`

para:

`config/mail.php`

Depois edite apenas:

`'password' => 'SENHA_DO_EMAIL_AQUI'`

e coloque a senha real da conta:

`noreply@portalrdp.online`

Não compartilhe essa senha.

## 2. Atualizar QA

Após subir os arquivos:

`https://portalrdp.online/qa/adm/atualizar`

Clique em:

`Aplicar atualização`

## 3. Testar convite em QA

Entre:

`https://portalrdp.online/qa/adm/usuarios`

Crie um usuário com um e-mail ao qual você tenha acesso.

O sistema deverá:
1. criar o usuário com status Pendente;
2. gerar token criptograficamente aleatório;
3. guardar somente SHA-256 do token;
4. enviar o link por SMTP;
5. registrar a data de envio.

## 4. E-mail recebido

O destinatário receberá:

`Você foi convidado para o Controle Operacional`

com o botão:

`Ativar meu acesso`

O link levará para:

`/qa/primeiro-acesso?token=...`

em QA ou:

`/primeiro-acesso?token=...`

em PROD.

## 5. Ativação

O usuário cria a própria senha.

Após ativar:
- token é apagado;
- convite não pode ser reutilizado;
- usuário fica Ativo;
- `ativado_em` é registrado.

## 6. Reenviar convite

Na lista de usuários, enquanto estiver Pendente:

`Convite`

permite reenviar.

Um reenvio invalida o link anterior.

## 7. Produção

Depois de validar QA:

`https://portalrdp.online/adm/atualizar`

e repita um teste controlado em PROD.

## Segurança das configurações

Os ZIPs de atualização não incluem:
- `config/database.php`
- `config/mail.php`

Portanto as senhas permanecem somente no servidor.
