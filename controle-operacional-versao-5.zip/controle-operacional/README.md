# Controle Operacional

Portal modular hospedado em `portalrdp.online`.

## Ambiente
- PHP: 8.4.24
- PROD: `https://portalrdp.online/`
- QA: `https://portalrdp.online/qa/`

## Versão atual
Versão 5

## Recursos
- Login por e-mail e senha
- Convite automático por e-mail
- Primeiro acesso por link seguro
- Usuários e perfis
- Permissões individuais por módulo
- PROD e QA separados

## Configurações sensíveis
Permanecem somente no servidor:

- `config/database.php`
- `config/mail.php`

Os ZIPs de atualização não incluem esses arquivos.

## Atualização
Leia:

`docs/versao-5-instalacao.md`
