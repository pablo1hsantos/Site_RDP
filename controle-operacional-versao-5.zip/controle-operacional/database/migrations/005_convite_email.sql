-- Versão 5 - Convite automático por e-mail
-- Documento de referência.
-- A execução real é feita pelo Migrator para tolerar diferenças de MariaDB/MySQL.

-- Novos campos em usuarios:
-- convite_token_hash CHAR(64) NULL
-- convite_enviado_em DATETIME NULL
-- ativado_em DATETIME NULL
