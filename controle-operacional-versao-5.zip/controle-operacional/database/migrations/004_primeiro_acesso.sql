-- Versão 4 - Primeiro Acesso
-- Migração não destrutiva.

ALTER TABLE usuarios
    ADD COLUMN IF NOT EXISTS primeiro_acesso_pendente TINYINT(1) NOT NULL DEFAULT 0 AFTER ativo,
    ADD COLUMN IF NOT EXISTS codigo_ativacao_hash VARCHAR(255) NULL AFTER primeiro_acesso_pendente,
    ADD COLUMN IF NOT EXISTS codigo_ativacao_expira DATETIME NULL AFTER codigo_ativacao_hash;

UPDATE usuarios
SET primeiro_acesso_pendente = 0
WHERE primeiro_acesso_pendente IS NULL;
