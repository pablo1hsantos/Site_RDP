<?php
declare(strict_types=1);

use Controle\Auth\Auth;

Auth::logout();

header('Location: ' . APP_BASE_PATH . '/login');
exit;
