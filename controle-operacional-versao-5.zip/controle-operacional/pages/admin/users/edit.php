<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
            if ($id === (int)(Auth::user()['id'] ?? 0) && empty($_POST['ativo'])) {
                throw new RuntimeException('Você não pode desativar seu próprio usuário.');
            }

            UserService::update($id, [
                'nome' => $_POST['nome'] ?? '',
                'email' => $_POST['email'] ?? '',
                'perfil' => $_POST['perfil'] ?? 'usuario',
                'ativo' => isset($_POST['ativo']),
            ]);

            $user = UserService::find($id);
            $success = 'Usuário atualizado.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar usuário - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Editar usuário</h1>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <form method="post" class="form form-card">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
        <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">

        <label>
            <span>Nome</span>
            <input type="text" name="nome" value="<?= htmlspecialchars($user['nome']) ?>" required>
        </label>

        <label>
            <span>E-mail</span>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </label>

        <label>
            <span>Perfil</span>
            <select name="perfil" required>
                <?php foreach (['usuario' => 'Usuário', 'gestor' => 'Gestor', 'administrador' => 'Administrador'] as $value => $label): ?>
                    <option value="<?= $value ?>" <?= $user['perfil'] === $value ? 'selected' : '' ?>>
                        <?= htmlspecialchars($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="check-row">
            <input type="checkbox" name="ativo" value="1" <?= (int)$user['ativo'] === 1 ? 'checked' : '' ?>>
            <span>Usuário ativo</span>
        </label>

        <button class="button" type="submit">Salvar alterações</button>
    </form>
</main>
</body>
</html>
