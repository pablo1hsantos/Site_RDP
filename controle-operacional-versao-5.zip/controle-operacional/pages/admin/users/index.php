<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Services\UserService;

Auth::requireAdmin();

$users = UserService::list();
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuários - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/">← Dashboard</a>
            <h1>Usuários</h1>
            <p class="muted">Administração de acessos do Controle Operacional.</p>
        </div>
        <div class="top-actions">
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
            <a class="button button-link" href="<?= APP_BASE_PATH ?>/adm/usuarios/novo">Novo usuário</a>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Perfil</th>
                    <th>Status</th>
                    <th>Último login</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <?php
                    if (!(bool)$u['ativo']) {
                        $status = 'Inativo';
                    } elseif (!empty($u['primeiro_acesso_pendente'])) {
                        $status = 'Pendente';
                    } else {
                        $status = 'Ativo';
                    }
                ?>
                <tr>
                    <td><?= htmlspecialchars($u['nome']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><?= htmlspecialchars(ucfirst($u['perfil'])) ?></td>
                    <td><?= htmlspecialchars($status) ?></td>
                    <td><?= htmlspecialchars($u['ultimo_login'] ?: 'Nunca') ?></td>
                    <td class="actions">
                        <a href="<?= APP_BASE_PATH ?>/adm/usuarios/editar?id=<?= (int)$u['id'] ?>">Editar</a>
                        <a href="<?= APP_BASE_PATH ?>/adm/usuarios/permissoes?id=<?= (int)$u['id'] ?>">Permissões</a>
                        <?php if (!empty($u['primeiro_acesso_pendente'])): ?>
                            <a href="<?= APP_BASE_PATH ?>/adm/usuarios/convite?id=<?= (int)$u['id'] ?>">Código</a>
                        <?php else: ?>
                            <a href="<?= APP_BASE_PATH ?>/adm/usuarios/senha?id=<?= (int)$u['id'] ?>">Senha</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
