<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$modules = UserService::modules();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } elseif ($user['perfil'] === 'administrador') {
        $error = 'Administradores já possuem acesso total automaticamente.';
    } else {
        try {
            UserService::savePermissions($id, $_POST['permissoes'] ?? []);
            $success = 'Permissões atualizadas.';
        } catch (Throwable $e) {
            $error = 'Não foi possível salvar as permissões.';
        }
    }
}

$current = UserService::permissions($id);
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
$actions = [
    'visualizar' => 'Ver',
    'criar' => 'Criar',
    'editar' => 'Editar',
    'excluir' => 'Excluir',
    'administrar' => 'Administrar',
];
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Permissões - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Permissões</h1>
            <p class="muted"><?= htmlspecialchars($user['nome']) ?> · <?= htmlspecialchars(ucfirst($user['perfil'])) ?></p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <?php if ($user['perfil'] === 'administrador'): ?>
        <div class="alert">Administradores possuem acesso total a todos os módulos.</div>
    <?php else: ?>
        <form method="post">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">

            <div class="table-wrap">
                <table class="table permissions-table">
                    <thead>
                        <tr>
                            <th>Módulo</th>
                            <?php foreach ($actions as $label): ?>
                                <th><?= htmlspecialchars($label) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($modules as $m): ?>
                        <?php $p = $current[(int)$m['id']] ?? []; ?>
                        <tr>
                            <td><?= htmlspecialchars($m['nome']) ?></td>
                            <?php foreach ($actions as $key => $label): ?>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="permissoes[<?= (int)$m['id'] ?>][<?= $key ?>]"
                                        value="1"
                                        <?= !empty($p[$key]) ? 'checked' : '' ?>
                                        aria-label="<?= htmlspecialchars($label . ' - ' . $m['nome']) ?>"
                                    >
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="form-actions">
                <button class="button" type="submit">Salvar permissões</button>
            </div>
        </form>
    <?php endif; ?>
</main>
</body>
</html>
