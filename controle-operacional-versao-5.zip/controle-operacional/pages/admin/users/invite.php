<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
            UserService::resendInvite($id);
            $user = UserService::find($id);
            $success = 'Novo convite enviado por e-mail.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Convite - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Convite de acesso</h1>
            <p class="muted"><?= htmlspecialchars($user['nome']) ?> · <?= htmlspecialchars($user['email']) ?></p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <?php if (!empty($user['primeiro_acesso_pendente'])): ?>
        <div class="form-card">
            <p>
                O usuário ainda não concluiu o primeiro acesso.
                Reenviar o convite invalida o link anterior e cria um novo link válido por 72 horas.
            </p>

            <?php if (!empty($user['convite_enviado_em'])): ?>
                <p class="muted">
                    Último envio: <?= htmlspecialchars((string)$user['convite_enviado_em']) ?>
                </p>
            <?php endif; ?>

            <form method="post">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                <button type="submit" class="button">Reenviar convite</button>
            </form>
        </div>
    <?php else: ?>
        <div class="alert">Este usuário já concluiu o primeiro acesso.</div>
    <?php endif; ?>
</main>
</body>
</html>
