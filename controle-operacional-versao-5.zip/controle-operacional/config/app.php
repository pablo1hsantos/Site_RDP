<?php
declare(strict_types=1);

return [
    'name' => 'Controle Operacional',
    'domain' => 'portalrdp.online',
    'timezone' => 'America/Sao_Paulo',

    'session' => [
        'name' => 'controle_operacional_session',
        'lifetime' => 60 * 60 * 8,
    ],
];
