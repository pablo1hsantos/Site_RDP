<?php
declare(strict_types=1);

/*
 * MODELO DE CONFIGURAÇÃO SMTP.
 * Em uma instalação nova, copie este arquivo para:
 *
 * config/mail.php
 *
 * Em atualizações, mantenha o mail.php existente no servidor.
 */

return [
    'host' => 'mail.portalrdp.online',
    'port' => 465,
    'encryption' => 'ssl',
    'username' => 'noreply@portalrdp.online',
    'password' => 'SENHA_DO_EMAIL_AQUI',

    'from_email' => 'noreply@portalrdp.online',
    'from_name' => 'Controle Operacional',

    'timeout' => 20,
];
