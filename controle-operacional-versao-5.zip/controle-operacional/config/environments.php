<?php
declare(strict_types=1);

return [
    'production' => [
        'label' => 'PROD',
        'google_sheet_id' => null,
        'google_drive_folder_id' => null,
    ],
    'qa' => [
        'label' => 'QA',
        'google_sheet_id' => null,
        'google_drive_folder_id' => null,
    ],
];
