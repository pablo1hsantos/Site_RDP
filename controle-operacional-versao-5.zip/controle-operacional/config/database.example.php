<?php
declare(strict_types=1);

/*
 * MODELO DE CONFIGURAÇÃO.
 * Copie este arquivo para database.php apenas em uma instalação nova.
 * Em atualizações, mantenha o database.php existente no servidor.
 */

return [
    'production' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'pablo718_controle_prod',
        'username' => 'pablo718_controle_prod',
        'password' => 'SENHA_PROD_AQUI',
        'charset' => 'utf8mb4',
    ],

    'qa' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'pablo718_controle_qa',
        'username' => 'pablo718_controle_qa',
        'password' => 'SENHA_QA_AQUI',
        'charset' => 'utf8mb4',
    ],
];
