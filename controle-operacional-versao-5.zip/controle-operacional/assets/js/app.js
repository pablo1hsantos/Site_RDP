window.CONTROLE = {
    startedAt: new Date().toISOString()
};
