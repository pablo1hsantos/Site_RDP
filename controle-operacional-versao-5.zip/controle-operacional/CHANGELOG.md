# Changelog

## Versão 5 - Convites por e-mail
- SMTP autenticado em `mail.portalrdp.online:465`
- Remetente `noreply@portalrdp.online`
- Convite automático ao criar usuário
- E-mail HTML e alternativa em texto
- Link único de ativação
- Token aleatório de 256 bits
- Somente hash SHA-256 do token armazenado
- Token expira em 72 horas
- Token apagado após ativação
- Reenvio invalida convite anterior
- Registro de data de envio
- Registro de data de ativação
- `config/mail.php` excluído dos ZIPs de atualização
- Sem dependência externa de biblioteca SMTP

## Versão 4 - Primeiro acesso
- Usuário cria a própria senha
- Status Pendente
- Primeiro acesso protegido
- Migração por ambiente

## Versão 3 - Usuários e permissões
- Administração de usuários
- Perfis e permissões individuais
- Credenciais de banco fora dos ZIPs

## Versão 2 - Autenticação
- Login e sessão PHP
- Banco separado entre PROD e QA

## Versão 1 - Fundação
- Estrutura modular
- PROD e QA
