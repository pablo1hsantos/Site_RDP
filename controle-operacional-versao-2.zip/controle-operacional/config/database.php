<?php
declare(strict_types=1);

/*
 * IMPORTANTE:
 * Preencha SOMENTE as senhas diretamente na HostGator.
 * Não compartilhe essas senhas no chat.
 *
 * Host padrão da HostGator/cPanel costuma ser localhost.
 */

return [
    'production' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'pablo718_controle_prod',
        'username' => 'pablo718_controle_prod',
        'password' => 'COLOQUE_A_SENHA_PROD_AQUI',
        'charset' => 'utf8mb4',
    ],

    'qa' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'pablo718_controle_qa',
        'username' => 'pablo718_controle_qa',
        'password' => 'COLOQUE_A_SENHA_QA_AQUI',
        'charset' => 'utf8mb4',
    ],
];
