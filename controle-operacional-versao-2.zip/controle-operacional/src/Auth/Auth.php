<?php
declare(strict_types=1);

namespace Controle\Auth;

use Controle\Core\Database;
use PDO;

final class Auth
{
    public static function check(): bool
    {
        return !empty($_SESSION['user']['id']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function attempt(string $email, string $password): bool
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT id, nome, email, senha_hash, perfil, ativo
             FROM usuarios
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute(['email' => mb_strtolower(trim($email))]);

        $user = $stmt->fetch();

        if (!$user || !(bool)$user['ativo']) {
            return false;
        }

        if (!password_verify($password, $user['senha_hash'])) {
            return false;
        }

        if (password_needs_rehash($user['senha_hash'], PASSWORD_DEFAULT)) {
            $novoHash = password_hash($password, PASSWORD_DEFAULT);
            $up = $pdo->prepare('UPDATE usuarios SET senha_hash = :hash WHERE id = :id');
            $up->execute(['hash' => $novoHash, 'id' => $user['id']]);
        }

        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id' => (int)$user['id'],
            'nome' => $user['nome'],
            'email' => $user['email'],
            'perfil' => $user['perfil'],
        ];

        $up = $pdo->prepare('UPDATE usuarios SET ultimo_login = NOW() WHERE id = :id');
        $up->execute(['id' => $user['id']]);

        return true;
    }

    public static function logout(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            header('Location: ' . APP_BASE_PATH . '/login');
            exit;
        }
    }

    public static function isAdmin(): bool
    {
        return (self::user()['perfil'] ?? null) === 'administrador';
    }

    public static function can(string $moduleCode, string $action = 'visualizar'): bool
    {
        if (!self::check()) {
            return false;
        }

        if (self::isAdmin()) {
            return true;
        }

        $allowedActions = ['visualizar', 'criar', 'editar', 'excluir', 'administrar'];

        if (!in_array($action, $allowedActions, true)) {
            return false;
        }

        $pdo = Database::connection();

        $sql = "SELECT pu.{$action}
                FROM permissoes_usuario pu
                INNER JOIN modulos m ON m.id = pu.modulo_id
                WHERE pu.usuario_id = :usuario_id
                  AND m.codigo = :codigo
                  AND m.ativo = 1
                LIMIT 1";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'usuario_id' => self::user()['id'],
            'codigo' => $moduleCode,
        ]);

        return (bool)$stmt->fetchColumn();
    }
}
