# Controle Operacional

Portal modular hospedado em `portalrdp.online`.

## Ambiente
- PHP: 8.4.24
- PROD: `https://portalrdp.online/`
- QA: `https://portalrdp.online/qa/`

## Versão atual
Versão 2

## Autenticação
- E-mail + senha
- Sessão PHP
- Perfis: Administrador, Gestor e Usuário
- Permissões por módulo

## Instalação
Leia:

`docs/versao-2-instalacao.md`

## Importante
As senhas dos bancos não estão incluídas no pacote.
Devem ser colocadas diretamente no arquivo:

`config/database.php`

na HostGator.
