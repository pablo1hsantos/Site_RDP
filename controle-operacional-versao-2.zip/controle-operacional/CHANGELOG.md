# Changelog

## Versão 2 - Autenticação e banco
- Banco PROD configurado para `pablo718_controle_prod`
- Banco QA configurado para `pablo718_controle_qa`
- Login por e-mail e senha
- Sessão PHP segura
- Logout
- CSRF básico
- Setup inicial de administrador
- Senhas armazenadas com `password_hash`
- Bancos e usuários separados entre PROD e QA
- Estrutura de perfis: administrador, gestor e usuário
- Estrutura de permissões por usuário e módulo
- Dashboard passa a exibir apenas módulos autorizados
- Rotas protegidas por autenticação

## Versão 1 - Fundação
- Estrutura modular inicial
- Roteamento PROD e QA
- Dashboard provisório
- Módulos reservados
- Configuração base
- Documentação inicial
