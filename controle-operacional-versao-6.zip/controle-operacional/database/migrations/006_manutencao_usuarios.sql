-- Versão 6 - Manutenção de Usuários
-- Documento de referência.
-- A execução real é feita por Controle\Core\Migrator::runV6().

-- usuarios:
-- auth_version INT UNSIGNED NOT NULL DEFAULT 1
-- trocar_senha_obrigatoria TINYINT(1) NOT NULL DEFAULT 0
-- arquivado TINYINT(1) NOT NULL DEFAULT 0
-- desativado_em DATETIME NULL
-- motivo_desativacao VARCHAR(255) NULL
-- arquivado_em DATETIME NULL

-- nova tabela:
-- logs_administrativos
