<?php
declare(strict_types=1);

namespace Controle\Auth;

use Controle\Core\Database;

final class Auth
{
    public static function check(): bool
    {
        return !empty($_SESSION['user']['id']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function attempt(string $identifier, string $password): bool
    {
        $pdo = Database::connection();

        $identifier = mb_strtolower(trim($identifier), 'UTF-8');

        $columnCheck = $pdo->query(
            "SELECT COUNT(*)
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'usuarios'
               AND COLUMN_NAME = 'usuario'"
        );

        $hasUsername = (int)$columnCheck->fetchColumn() > 0;

        if ($hasUsername) {
            $stmt = $pdo->prepare(
                'SELECT *
                 FROM usuarios
                 WHERE LOWER(email) = :identifier
                    OR LOWER(usuario) = :identifier
                 LIMIT 1'
            );
        } else {
            // Compatibilidade durante a atualização:
            // enquanto a coluna usuario ainda não existe, o e-mail continua funcionando.
            $stmt = $pdo->prepare(
                'SELECT *
                 FROM usuarios
                 WHERE LOWER(email) = :identifier
                 LIMIT 1'
            );
        }

        $stmt->execute([
            'identifier' => $identifier,
        ]);

        $user = $stmt->fetch();

        if (
            !$user ||
            !(bool)$user['ativo'] ||
            !empty($user['primeiro_acesso_pendente']) ||
            !empty($user['arquivado'])
        ) {
            return false;
        }

        if (!password_verify($password, $user['senha_hash'])) {
            return false;
        }

        if (password_needs_rehash($user['senha_hash'], PASSWORD_DEFAULT)) {
            $novoHash = password_hash($password, PASSWORD_DEFAULT);

            $up = $pdo->prepare(
                'UPDATE usuarios
                 SET senha_hash = :hash, atualizado_em = NOW()
                 WHERE id = :id'
            );

            $up->execute([
                'hash' => $novoHash,
                'id' => $user['id'],
            ]);
        }

        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id' => (int)$user['id'],
            'nome' => $user['nome'],
            'usuario' => $user['usuario'] ?? explode('@', (string)$user['email'], 2)[0],
            'email' => $user['email'],
            'perfil' => $user['perfil'],
            'auth_version' => isset($user['auth_version'])
                ? (int)$user['auth_version']
                : 1,
            'trocar_senha_obrigatoria' =>
                !empty($user['trocar_senha_obrigatoria']),
        ];

        $up = $pdo->prepare(
            'UPDATE usuarios
             SET ultimo_login = NOW()
             WHERE id = :id'
        );

        $up->execute([
            'id' => $user['id'],
        ]);

        return true;
    }

    public static function logout(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    public static function requireLogin(): void
    {
        if (!self::check() || !self::validateSession()) {
            self::logout();
            header('Location: ' . APP_BASE_PATH . '/login');
            exit;
        }
    }

    public static function validateSession(): bool
    {
        if (!self::check()) {
            return false;
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE id = :id
             LIMIT 1'
        );

        $stmt->execute([
            'id' => (int)$_SESSION['user']['id'],
        ]);

        $current = $stmt->fetch();

        if (!$current) {
            return false;
        }

        if (!(bool)$current['ativo'] || !empty($current['arquivado'])) {
            return false;
        }

        if (isset($current['auth_version'])) {
            $sessionVersion = (int)($_SESSION['user']['auth_version'] ?? 1);

            if ((int)$current['auth_version'] !== $sessionVersion) {
                return false;
            }
        }

        $_SESSION['user']['nome'] = $current['nome'];
        $_SESSION['user']['usuario'] =
            $current['usuario'] ?? explode('@', (string)$current['email'], 2)[0];
        $_SESSION['user']['email'] = $current['email'];
        $_SESSION['user']['perfil'] = $current['perfil'];
        $_SESSION['user']['auth_version'] =
            isset($current['auth_version'])
                ? (int)$current['auth_version']
                : 1;
        $_SESSION['user']['trocar_senha_obrigatoria'] =
            !empty($current['trocar_senha_obrigatoria']);

        return true;
    }

    public static function requiresPasswordChange(): bool
    {
        return !empty($_SESSION['user']['trocar_senha_obrigatoria']);
    }

    public static function syncCurrentSession(
        int $authVersion,
        bool $forcePasswordChange
    ): void {
        if (!self::check()) {
            return;
        }

        $_SESSION['user']['auth_version'] = $authVersion;
        $_SESSION['user']['trocar_senha_obrigatoria'] = $forcePasswordChange;
    }

    public static function requireAdmin(): void
    {
        self::requireLogin();

        if (!self::isAdmin()) {
            http_response_code(403);
            echo 'Acesso negado.';
            exit;
        }
    }

    public static function isAdmin(): bool
    {
        return (self::user()['perfil'] ?? null) === 'administrador';
    }

    public static function can(
        string $moduleCode,
        string $action = 'visualizar'
    ): bool {
        if (!self::check()) {
            return false;
        }

        if (self::isAdmin()) {
            return true;
        }

        $allowedActions = [
            'visualizar',
            'criar',
            'editar',
            'excluir',
            'administrar',
        ];

        if (!in_array($action, $allowedActions, true)) {
            return false;
        }

        $pdo = Database::connection();

        $sql = "SELECT pu.{$action}
                FROM permissoes_usuario pu
                INNER JOIN modulos m ON m.id = pu.modulo_id
                WHERE pu.usuario_id = :usuario_id
                  AND m.codigo = :codigo
                  AND m.ativo = 1
                LIMIT 1";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            'usuario_id' => self::user()['id'],
            'codigo' => $moduleCode,
        ]);

        return (bool)$stmt->fetchColumn();
    }
}
