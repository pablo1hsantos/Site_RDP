<?php
declare(strict_types=1);

namespace Controle\Services;

use Controle\Auth\Auth;
use Controle\Core\Database;
use InvalidArgumentException;
use PDOException;
use RuntimeException;

final class UserService
{
    public static function list(bool $archived = false): array
    {
        $pdo = Database::connection();

        $where = $archived ? 'arquivado = 1' : '(arquivado = 0 OR arquivado IS NULL)';

        return $pdo->query(
            "SELECT *
             FROM usuarios
             WHERE {$where}
             ORDER BY nome"
        )->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE id = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $id]);

        $user = $stmt->fetch();

        return $user ?: null;
    }

    public static function createPendingAndInvite(array $data): array
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');
        $usuario = self::normalizeUsername(
            (string)($data['usuario'] ?? self::usernameFromEmail($email))
        );

        self::validateBase($nome, $email, $perfil);
        self::validateUsername($usuario);

        $token = self::generateInviteToken();
        $temporaryPassword = bin2hex(random_bytes(32));

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO usuarios
                (
                    nome, usuario, email, senha_hash, perfil, ativo,
                    primeiro_acesso_pendente,
                    codigo_ativacao_hash,
                    codigo_ativacao_expira,
                    convite_token_hash,
                    convite_enviado_em,
                    ativado_em,
                    auth_version,
                    trocar_senha_obrigatoria,
                    arquivado,
                    criado_em, atualizado_em
                )
                VALUES
                (
                    :nome, :usuario, :email, :senha_hash, :perfil, :ativo,
                    1,
                    NULL,
                    DATE_ADD(NOW(), INTERVAL 72 HOUR),
                    :token_hash,
                    NULL,
                    NULL,
                    1,
                    0,
                    0,
                    NOW(), NOW()
                )'
            );

            $stmt->execute([
                'nome' => $nome,
                'usuario' => $usuario,
                'email' => $email,
                'senha_hash' => password_hash($temporaryPassword, PASSWORD_DEFAULT),
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'token_hash' => hash('sha256', $token),
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail ou nome de usuário.');
            }
            throw $e;
        }

        $id = (int)$pdo->lastInsertId();

        AdminLogService::record($id, 'USUARIO_CRIADO', 'Usuário criado com primeiro acesso pendente.');

        try {
            self::sendInvite($id, $token);
        } catch (\Throwable $e) {
            return [
                'id' => $id,
                'sent' => false,
                'error' => $e->getMessage(),
            ];
        }

        return [
            'id' => $id,
            'sent' => true,
            'error' => null,
        ];
    }

    public static function resendInvite(int $id): void
    {
        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!empty($user['arquivado'])) {
            throw new InvalidArgumentException('Usuário arquivado não pode receber convite.');
        }

        if (!(bool)($user['primeiro_acesso_pendente'] ?? false)) {
            throw new InvalidArgumentException('Este usuário já concluiu o primeiro acesso.');
        }

        if (!(bool)$user['ativo']) {
            throw new InvalidArgumentException('Ative o usuário antes de reenviar o convite.');
        }

        $token = self::generateInviteToken();
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET convite_token_hash = :token_hash,
                 codigo_ativacao_expira = DATE_ADD(NOW(), INTERVAL 72 HOUR),
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'token_hash' => hash('sha256', $token),
            'id' => $id,
        ]);

        self::sendInvite($id, $token);
        AdminLogService::record($id, 'CONVITE_REENVIADO', 'Novo convite de acesso enviado.');
    }

    public static function findPendingByToken(string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
            return null;
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE convite_token_hash = :token_hash
               AND primeiro_acesso_pendente = 1
               AND ativo = 1
               AND (arquivado = 0 OR arquivado IS NULL)
             LIMIT 1'
        );

        $stmt->execute([
            'token_hash' => hash('sha256', $token),
        ]);

        $user = $stmt->fetch();

        if (!$user) {
            return null;
        }

        if (
            empty($user['codigo_ativacao_expira']) ||
            strtotime((string)$user['codigo_ativacao_expira']) < time()
        ) {
            return null;
        }

        return $user;
    }

    public static function activateByToken(string $token, string $password): void
    {
        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $user = self::findPendingByToken($token);

        if (!$user) {
            throw new InvalidArgumentException('Convite inválido ou expirado.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :senha_hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 convite_token_hash = NULL,
                 ativado_em = NOW(),
                 trocar_senha_obrigatoria = 0,
                 atualizado_em = NOW()
             WHERE id = :id
               AND primeiro_acesso_pendente = 1'
        );

        $stmt->execute([
            'senha_hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $user['id'],
        ]);
    }

    public static function update(int $id, array $data): void
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');
        $usuario = self::normalizeUsername((string)($data['usuario'] ?? ''));

        self::validateBase($nome, $email, $perfil);
        self::validateUsername($usuario);

        $current = Auth::user();
        if (
            (int)($current['id'] ?? 0) === $id &&
            ($current['perfil'] ?? null) === 'administrador' &&
            $perfil !== 'administrador'
        ) {
            throw new InvalidArgumentException(
                'Você não pode remover o perfil de administrador do seu próprio usuário.'
            );
        }

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'UPDATE usuarios
                 SET nome = :nome,
                     usuario = :usuario,
                     email = :email,
                     perfil = :perfil,
                     atualizado_em = NOW()
                 WHERE id = :id'
            );

            $stmt->execute([
                'nome' => $nome,
                'usuario' => $usuario,
                'email' => $email,
                'perfil' => $perfil,
                'id' => $id,
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail ou nome de usuário.');
            }
            throw $e;
        }

        AdminLogService::record($id, 'DADOS_ATUALIZADOS', 'Nome, e-mail ou perfil atualizados.');
    }

    public static function setActive(int $id, bool $active, ?string $reason = null): void
    {
        self::preventSelfCriticalAction($id, $active ? 'reativar' : 'desativar');

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!empty($user['arquivado']) && $active) {
            throw new InvalidArgumentException('Desarquive o usuário antes de reativá-lo.');
        }

        $pdo = Database::connection();

        if ($active) {
            $stmt = $pdo->prepare(
                'UPDATE usuarios
                 SET ativo = 1,
                     desativado_em = NULL,
                     motivo_desativacao = NULL,
                     atualizado_em = NOW()
                 WHERE id = :id'
            );
            $stmt->execute(['id' => $id]);

            AdminLogService::record($id, 'USUARIO_REATIVADO', null);
            return;
        }

        $reason = trim((string)$reason);

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET ativo = 0,
                 desativado_em = NOW(),
                 motivo_desativacao = :motivo,
                 auth_version = COALESCE(auth_version, 1) + 1,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'motivo' => $reason !== '' ? mb_substr($reason, 0, 255) : null,
            'id' => $id,
        ]);

        AdminLogService::record(
            $id,
            'USUARIO_DESATIVADO',
            $reason !== '' ? 'Motivo: ' . $reason : null
        );
    }

    public static function revokeSessions(int $id): void
    {
        self::preventSelfCriticalAction($id, 'revogar a própria sessão');

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET auth_version = COALESCE(auth_version, 1) + 1,
                 atualizado_em = NOW()
             WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);

        AdminLogService::record($id, 'SESSOES_REVOGADAS', 'Todas as sessões existentes foram invalidadas.');
    }

    public static function forcePasswordChange(int $id): void
    {
        self::preventSelfCriticalAction($id, 'forçar sua própria troca de senha');

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!empty($user['primeiro_acesso_pendente'])) {
            throw new InvalidArgumentException('O usuário ainda não concluiu o primeiro acesso.');
        }

        if (!empty($user['arquivado'])) {
            throw new InvalidArgumentException('Usuário arquivado não pode receber esta ação.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET trocar_senha_obrigatoria = 1,
                 auth_version = COALESCE(auth_version, 1) + 1,
                 atualizado_em = NOW()
             WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);

        AdminLogService::record(
            $id,
            'TROCA_SENHA_FORCADA',
            'No próximo login o usuário deverá criar uma nova senha.'
        );
    }

    public static function archive(int $id, ?string $reason = null): void
    {
        self::preventSelfCriticalAction($id, 'arquivar');

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!empty($user['arquivado'])) {
            throw new InvalidArgumentException('Usuário já está arquivado.');
        }

        $reason = trim((string)$reason);

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET arquivado = 1,
                 ativo = 0,
                 arquivado_em = NOW(),
                 desativado_em = COALESCE(desativado_em, NOW()),
                 motivo_desativacao = :motivo,
                 auth_version = COALESCE(auth_version, 1) + 1,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'motivo' => $reason !== '' ? mb_substr($reason, 0, 255) : null,
            'id' => $id,
        ]);

        AdminLogService::record(
            $id,
            'USUARIO_ARQUIVADO',
            $reason !== '' ? 'Motivo: ' . $reason : null
        );
    }

    public static function unarchive(int $id): void
    {
        self::preventSelfCriticalAction($id, 'desarquivar');

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (empty($user['arquivado'])) {
            throw new InvalidArgumentException('Usuário não está arquivado.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET arquivado = 0,
                 arquivado_em = NULL,
                 atualizado_em = NOW()
             WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);

        AdminLogService::record(
            $id,
            'USUARIO_DESARQUIVADO',
            'Usuário voltou à lista normal, permanecendo inativo.'
        );
    }

    public static function changeOwnPassword(
        int $id,
        string $currentPassword,
        string $newPassword
    ): int {
        if (strlen($newPassword) < 10) {
            throw new InvalidArgumentException('A nova senha deve ter pelo menos 10 caracteres.');
        }

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!password_verify($currentPassword, (string)$user['senha_hash'])) {
            throw new InvalidArgumentException('Senha atual inválida.');
        }

        if (password_verify($newPassword, (string)$user['senha_hash'])) {
            throw new InvalidArgumentException('A nova senha deve ser diferente da senha atual.');
        }

        $nextVersion = (int)($user['auth_version'] ?? 1) + 1;

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :senha_hash,
                 trocar_senha_obrigatoria = 0,
                 auth_version = :auth_version,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'senha_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
            'auth_version' => $nextVersion,
            'id' => $id,
        ]);

        AdminLogService::record(
            $id,
            'SENHA_ALTERADA',
            'Senha alterada pelo próprio usuário.'
        );

        return $nextVersion;
    }

    public static function resetPassword(int $id, string $password): void
    {
        self::preventSelfCriticalAction($id, 'redefinir sua própria senha por administração');

        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha temporária deve ter pelo menos 10 caracteres.');
        }

        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!empty($user['arquivado'])) {
            throw new InvalidArgumentException('Usuário arquivado não pode ter a senha redefinida.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 convite_token_hash = NULL,
                 ativado_em = COALESCE(ativado_em, NOW()),
                 trocar_senha_obrigatoria = 1,
                 auth_version = COALESCE(auth_version, 1) + 1,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $id,
        ]);

        AdminLogService::record(
            $id,
            'SENHA_TEMPORARIA_DEFINIDA',
            'Administrador definiu senha temporária; troca obrigatória no próximo login.'
        );
    }

    public static function modules(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT id, codigo, nome
             FROM modulos
             WHERE ativo = 1
             ORDER BY nome'
        )->fetchAll();
    }

    public static function permissions(int $userId): array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT modulo_id, visualizar, criar, editar, excluir, administrar
             FROM permissoes_usuario
             WHERE usuario_id = :usuario_id'
        );
        $stmt->execute(['usuario_id' => $userId]);

        $out = [];

        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['modulo_id']] = $row;
        }

        return $out;
    }

    public static function savePermissions(int $userId, array $permissions): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $del = $pdo->prepare(
                'DELETE FROM permissoes_usuario
                 WHERE usuario_id = :usuario_id'
            );
            $del->execute(['usuario_id' => $userId]);

            $ins = $pdo->prepare(
                'INSERT INTO permissoes_usuario
                (usuario_id, modulo_id, visualizar, criar, editar, excluir, administrar)
                VALUES
                (:usuario_id, :modulo_id, :visualizar, :criar, :editar, :excluir, :administrar)'
            );

            foreach ($permissions as $moduleId => $row) {
                $moduleId = (int)$moduleId;

                if ($moduleId <= 0) {
                    continue;
                }

                $ins->execute([
                    'usuario_id' => $userId,
                    'modulo_id' => $moduleId,
                    'visualizar' => !empty($row['visualizar']) ? 1 : 0,
                    'criar' => !empty($row['criar']) ? 1 : 0,
                    'editar' => !empty($row['editar']) ? 1 : 0,
                    'excluir' => !empty($row['excluir']) ? 1 : 0,
                    'administrar' => !empty($row['administrar']) ? 1 : 0,
                ]);
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        AdminLogService::record(
            $userId,
            'PERMISSOES_ATUALIZADAS',
            'Matriz de permissões atualizada.'
        );
    }

    private static function sendInvite(int $id, string $token): void
    {
        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        $host = $_SERVER['HTTP_HOST'] ?? 'portalrdp.online';

        $activationUrl =
            'https://' . $host .
            APP_BASE_PATH .
            '/primeiro-acesso?token=' .
            urlencode($token);

        $expiresAt = date('d/m/Y H:i', strtotime('+72 hours'));

        MailService::sendInvite(
            (string)$user['email'],
            (string)$user['nome'],
            $activationUrl,
            $expiresAt
        );

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET convite_enviado_em = NOW(),
                 atualizado_em = NOW()
             WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);
    }

    private static function validateBase(
        string $nome,
        string $email,
        string $perfil
    ): void {
        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do usuário.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Informe um e-mail válido.');
        }

        if (!in_array($perfil, ['administrador', 'gestor', 'usuario'], true)) {
            throw new InvalidArgumentException('Perfil inválido.');
        }
    }

    private static function preventSelfCriticalAction(int $id, string $action): void
    {
        $currentId = (int)(Auth::user()['id'] ?? 0);

        if ($currentId === $id) {
            throw new RuntimeException(
                'Esta ação não pode ser aplicada ao seu próprio usuário: ' . $action . '.'
            );
        }
    }

    private static function validateUsername(string $usuario): void
    {
        if ($usuario === '') {
            throw new InvalidArgumentException('Informe um nome de usuário.');
        }

        if (strlen($usuario) < 3) {
            throw new InvalidArgumentException(
                'O nome de usuário deve ter pelo menos 3 caracteres.'
            );
        }

        if (!preg_match('/^[a-z0-9._-]+$/', $usuario)) {
            throw new InvalidArgumentException(
                'O usuário pode conter apenas letras, números, ponto, hífen e sublinhado.'
            );
        }
    }

    private static function normalizeUsername(string $value): string
    {
        $value = mb_strtolower(trim($value), 'UTF-8');
        $value = preg_replace('/[^a-z0-9._-]+/', '_', $value) ?? '';
        $value = trim($value, '._-');
        $value = preg_replace('/_+/', '_', $value) ?? '';

        return mb_substr($value, 0, 80);
    }

    private static function usernameFromEmail(string $email): string
    {
        return explode('@', mb_strtolower(trim($email), 'UTF-8'), 2)[0] ?? '';
    }

    private static function generateInviteToken(): string
    {
        return bin2hex(random_bytes(32));
    }
}
