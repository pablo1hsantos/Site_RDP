<?php
declare(strict_types=1);

namespace Controle\Services;

use Controle\Auth\Auth;
use Controle\Core\Database;

final class AdminLogService
{
    public static function record(int $targetUserId, string $action, ?string $details = null): void
    {
        $admin = Auth::user();

        if (!$admin || empty($admin['id'])) {
            return;
        }

        try {
            $pdo = Database::connection();

            $stmt = $pdo->prepare(
                'INSERT INTO logs_administrativos
                 (administrador_id, usuario_alvo_id, acao, detalhes, ip, criado_em)
                 VALUES
                 (:administrador_id, :usuario_alvo_id, :acao, :detalhes, :ip, NOW())'
            );

            $stmt->execute([
                'administrador_id' => (int)$admin['id'],
                'usuario_alvo_id' => $targetUserId,
                'acao' => mb_substr($action, 0, 80),
                'detalhes' => $details !== null ? mb_substr($details, 0, 500) : null,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
        } catch (\Throwable $e) {
            // O log nunca deve impedir a ação principal.
        }
    }

    public static function recentForUser(int $targetUserId, int $limit = 30): array
    {
        $pdo = Database::connection();

        $limit = max(1, min(100, $limit));

        $stmt = $pdo->prepare(
            "SELECT l.acao, l.detalhes, l.ip, l.criado_em,
                    a.nome AS administrador_nome
             FROM logs_administrativos l
             INNER JOIN usuarios a ON a.id = l.administrador_id
             WHERE l.usuario_alvo_id = :usuario_alvo_id
             ORDER BY l.id DESC
             LIMIT {$limit}"
        );

        $stmt->execute(['usuario_alvo_id' => $targetUserId]);

        return $stmt->fetchAll();
    }
}
