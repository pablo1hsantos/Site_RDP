<?php
declare(strict_types=1);

namespace Controle\Helpers;

final class UserFormatter
{
    public static function displayName(?string $name): string
    {
        return mb_strtoupper(trim((string)$name), 'UTF-8');
    }

    public static function username(?string $username): string
    {
        return mb_strtolower(trim((string)$username), 'UTF-8');
    }
}
