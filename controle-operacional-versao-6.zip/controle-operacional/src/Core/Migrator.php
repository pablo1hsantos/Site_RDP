<?php
declare(strict_types=1);

namespace Controle\Core;

use PDO;
use RuntimeException;

final class Migrator
{
    public static function runV4(): void
    {
        $pdo = Database::connection();

        $columns = [
            'primeiro_acesso_pendente' => "
                ALTER TABLE usuarios
                ADD COLUMN primeiro_acesso_pendente TINYINT(1) NOT NULL DEFAULT 0 AFTER ativo
            ",
            'codigo_ativacao_hash' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_hash VARCHAR(255) NULL AFTER primeiro_acesso_pendente
            ",
            'codigo_ativacao_expira' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_expira DATETIME NULL AFTER codigo_ativacao_hash
            ",
        ];

        self::addMissingColumns($pdo, 'usuarios', $columns);
    }

    public static function runV5(): void
    {
        self::runV4();

        $pdo = Database::connection();

        $columns = [
            'convite_token_hash' => "
                ALTER TABLE usuarios
                ADD COLUMN convite_token_hash CHAR(64) NULL AFTER codigo_ativacao_expira
            ",
            'convite_enviado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN convite_enviado_em DATETIME NULL AFTER convite_token_hash
            ",
            'ativado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN ativado_em DATETIME NULL AFTER convite_enviado_em
            ",
        ];

        self::addMissingColumns($pdo, 'usuarios', $columns);
    }

    public static function runV6(): void
    {
        self::runV5();

        $pdo = Database::connection();

        $columns = [
            'auth_version' => "
                ALTER TABLE usuarios
                ADD COLUMN auth_version INT UNSIGNED NOT NULL DEFAULT 1 AFTER ativado_em
            ",
            'trocar_senha_obrigatoria' => "
                ALTER TABLE usuarios
                ADD COLUMN trocar_senha_obrigatoria TINYINT(1) NOT NULL DEFAULT 0 AFTER auth_version
            ",
            'arquivado' => "
                ALTER TABLE usuarios
                ADD COLUMN arquivado TINYINT(1) NOT NULL DEFAULT 0 AFTER trocar_senha_obrigatoria
            ",
            'desativado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN desativado_em DATETIME NULL AFTER arquivado
            ",
            'motivo_desativacao' => "
                ALTER TABLE usuarios
                ADD COLUMN motivo_desativacao VARCHAR(255) NULL AFTER desativado_em
            ",
            'arquivado_em' => "
                ALTER TABLE usuarios
                ADD COLUMN arquivado_em DATETIME NULL AFTER motivo_desativacao
            ",
            'usuario' => "
                ALTER TABLE usuarios
                ADD COLUMN usuario VARCHAR(80) NULL AFTER nome
            ",
        ];

        self::addMissingColumns($pdo, 'usuarios', $columns);

        self::populateUsernames($pdo);
        self::ensureUsernameUniqueIndex($pdo);

        $pdo->exec("
            CREATE TABLE IF NOT EXISTS logs_administrativos (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                administrador_id INT UNSIGNED NOT NULL,
                usuario_alvo_id INT UNSIGNED NOT NULL,
                acao VARCHAR(80) NOT NULL,
                detalhes VARCHAR(500) NULL,
                ip VARCHAR(45) NULL,
                criado_em DATETIME NOT NULL,
                INDEX idx_log_admin (administrador_id),
                INDEX idx_log_alvo (usuario_alvo_id),
                INDEX idx_log_data (criado_em),
                CONSTRAINT fk_log_admin
                    FOREIGN KEY (administrador_id) REFERENCES usuarios(id),
                CONSTRAINT fk_log_alvo
                    FOREIGN KEY (usuario_alvo_id) REFERENCES usuarios(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
    }

    private static function populateUsernames(PDO $pdo): void
    {
        $rows = $pdo->query(
            "SELECT id, email, usuario
             FROM usuarios
             ORDER BY id"
        )->fetchAll();

        $used = [];

        foreach ($rows as $row) {
            $current = trim((string)($row['usuario'] ?? ''));

            if ($current !== '') {
                $normalized = self::normalizeUsername($current);

                if ($normalized === '') {
                    $normalized = 'usuario' . (int)$row['id'];
                }
            } else {
                $email = mb_strtolower(trim((string)$row['email']));
                $local = explode('@', $email, 2)[0] ?? '';
                $normalized = self::normalizeUsername($local);

                if ($normalized === '') {
                    $normalized = 'usuario' . (int)$row['id'];
                }
            }

            $base = $normalized;
            $suffix = 2;

            while (isset($used[$normalized])) {
                $normalized = mb_substr($base, 0, 72) . '_' . $suffix;
                $suffix++;
            }

            $used[$normalized] = true;

            $stmt = $pdo->prepare(
                "UPDATE usuarios
                 SET usuario = :usuario
                 WHERE id = :id"
            );

            $stmt->execute([
                'usuario' => $normalized,
                'id' => (int)$row['id'],
            ]);
        }

        $pdo->exec(
            "ALTER TABLE usuarios
             MODIFY usuario VARCHAR(80) NOT NULL"
        );
    }

    private static function ensureUsernameUniqueIndex(PDO $pdo): void
    {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'usuarios'
               AND INDEX_NAME = 'uq_usuarios_usuario'"
        );
        $stmt->execute();

        if ((int)$stmt->fetchColumn() === 0) {
            $pdo->exec(
                "ALTER TABLE usuarios
                 ADD UNIQUE INDEX uq_usuarios_usuario (usuario)"
            );
        }
    }

    private static function normalizeUsername(string $value): string
    {
        $value = mb_strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9._-]+/', '_', $value) ?? '';
        $value = trim($value, '._-');
        $value = preg_replace('/_+/', '_', $value) ?? '';

        return mb_substr($value, 0, 80);
    }

    private static function addMissingColumns(PDO $pdo, string $table, array $columns): void
    {
        foreach ($columns as $column => $sql) {
            if (!self::columnExists($pdo, $table, $column)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = :table_name
               AND COLUMN_NAME = :column_name'
        );

        $stmt->execute([
            'table_name' => $table,
            'column_name' => $column,
        ]);

        return (int)$stmt->fetchColumn() > 0;
    }
}
