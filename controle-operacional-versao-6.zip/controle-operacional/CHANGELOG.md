# Changelog

## Versão 6 - Manutenção de usuários
- Desativação e reativação de usuários
- Revogação imediata de sessões
- Versão de autenticação por usuário
- Troca de senha obrigatória no próximo login
- Alteração da própria senha
- Senha temporária administrativa com troca obrigatória
- Arquivamento sem exclusão definitiva
- Lista separada de usuários arquivados
- Motivo opcional de desativação/arquivamento
- Registro de data de desativação e arquivamento
- Histórico de ações administrativas
- Bloqueio de ações críticas sobre o próprio administrador
- Credenciais de banco e SMTP continuam fora dos ZIPs

## Versão 5 - Convites por e-mail
- SMTP autenticado
- Convite automático por e-mail
- Link único de ativação
- Reenvio de convite

## Versão 4 - Primeiro acesso
- Usuário cria a própria senha
- Status Pendente

## Versão 3 - Usuários e permissões
- Administração de usuários
- Perfis e permissões individuais

## Versão 2 - Autenticação
- Login e sessão PHP
- Banco separado entre PROD e QA

## Versão 1 - Fundação
- Estrutura modular
- PROD e QA
