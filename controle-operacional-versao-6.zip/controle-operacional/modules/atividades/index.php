<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Helpers\UserFormatter;

$base = APP_BASE_PATH;
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
$user = Auth::user();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Atividades - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= $base ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= $base ?>/">← Dashboard</a>
            <h1>Atividades</h1>
            <p class="muted">Módulo reservado. Funcionalidades entram nas próximas etapas.</p>
        </div>
        <div class="top-actions">
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
            <span class="muted"><?= htmlspecialchars(UserFormatter::displayName($user['nome'] ?? '')) ?></span>
            <a href="<?= $base ?>/logout">Sair</a>
        </div>
    </div>
</main>
</body>
</html>
