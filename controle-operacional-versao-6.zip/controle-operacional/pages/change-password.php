<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireLogin();

$error = null;
$success = null;
$forced = Auth::requiresPasswordChange();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        $senhaAtual = (string)($_POST['senha_atual'] ?? '');
        $novaSenha = (string)($_POST['nova_senha'] ?? '');
        $confirmacao = (string)($_POST['confirmacao'] ?? '');

        try {
            if ($novaSenha !== $confirmacao) {
                throw new RuntimeException('As novas senhas não conferem.');
            }

            $newVersion = UserService::changeOwnPassword(
                (int)Auth::user()['id'],
                $senhaAtual,
                $novaSenha
            );

            Auth::syncCurrentSession($newVersion, false);
            session_regenerate_id(true);

            $success = 'Senha alterada com sucesso.';
            $forced = false;
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alterar senha - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="auth-page">
    <section class="auth-card">
        <div class="auth-header">
            <div>
                <h1>Alterar senha</h1>
                <p>
                    <?= $forced
                        ? 'A troca de senha é obrigatória para continuar.'
                        : 'Atualize sua senha de acesso.' ?>
                </p>
            </div>
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <a class="button button-link" href="<?= APP_BASE_PATH ?>/">Ir para o dashboard</a>
        <?php else: ?>
            <form method="post" class="form">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

                <label>
                    <span>Senha atual</span>
                    <input
                        type="password"
                        name="senha_atual"
                        autocomplete="current-password"
                        required
                    >
                </label>

                <label>
                    <span>Nova senha</span>
                    <input
                        type="password"
                        name="nova_senha"
                        minlength="10"
                        autocomplete="new-password"
                        required
                    >
                </label>

                <label>
                    <span>Confirmar nova senha</span>
                    <input
                        type="password"
                        name="confirmacao"
                        minlength="10"
                        autocomplete="new-password"
                        required
                    >
                </label>

                <button type="submit" class="button">Salvar nova senha</button>
            </form>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
