<?php
declare(strict_types=1);

use Controle\Core\Csrf;
use Controle\Core\Database;

$error = null;
$success = null;

try {
    $pdo = Database::connection();
} catch (Throwable $e) {
    $pdo = null;
    $error = 'Configure primeiro a senha do banco em config/database.php.';
}

if ($pdo) {
    $schema = file_get_contents(APP_ROOT . '/database/schema.sql');

    foreach (array_filter(array_map('trim', explode(';', $schema))) as $statement) {
        if ($statement !== '') {
            $pdo->exec($statement);
        }
    }

    $exists = (int)$pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn();

    if ($exists > 0) {
        http_response_code(403);
        $success = 'A configuração inicial já foi concluída. O setup está bloqueado.';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Csrf::validate($_POST['_csrf'] ?? null)) {
            $error = 'Sessão expirada. Atualize a página.';
        } else {
            $nome = trim((string)($_POST['nome'] ?? ''));
            $email = mb_strtolower(trim((string)($_POST['email'] ?? '')));
            $usuario = mb_strtolower(trim((string)($_POST['usuario'] ?? '')));
            $senha = (string)($_POST['senha'] ?? '');
            $confirmacao = (string)($_POST['confirmacao'] ?? '');

            if (
                $nome === '' ||
                !filter_var($email, FILTER_VALIDATE_EMAIL) ||
                !preg_match('/^[a-z0-9._-]{3,80}$/', $usuario)
            ) {
                $error = 'Informe nome, usuário e e-mail válidos.';
            } elseif (strlen($senha) < 10) {
                $error = 'A senha deve ter pelo menos 10 caracteres.';
            } elseif ($senha !== $confirmacao) {
                $error = 'As senhas não conferem.';
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO usuarios
                    (nome, usuario, email, senha_hash, perfil, ativo, criado_em, atualizado_em)
                    VALUES
                    (:nome, :usuario, :email, :senha_hash, "administrador", 1, NOW(), NOW())'
                );

                $stmt->execute([
                    'nome' => $nome,
                    'usuario' => $usuario,
                    'email' => $email,
                    'senha_hash' => password_hash($senha, PASSWORD_DEFAULT),
                ]);

                $success = 'Administrador criado com sucesso. Agora acesse o login.';
            }
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Configuração inicial - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="auth-page">
    <section class="auth-card">
        <div class="auth-header">
            <div>
                <h1>Configuração inicial</h1>
                <p><?= htmlspecialchars(APP_NAME) ?></p>
            </div>
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <p><a class="button button-link" href="<?= APP_BASE_PATH ?>/login">Ir para o login</a></p>
        <?php elseif ($pdo): ?>
            <form method="post" class="form">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

                <label>
                    <span>Nome</span>
                    <input type="text" name="nome" value="Pablo Santos" required>
                </label>

                <label>
                    <span>Usuário</span>
                    <input
                        type="text"
                        name="usuario"
                        value="pablo_santos"
                        minlength="3"
                        maxlength="80"
                        pattern="[A-Za-z0-9._-]+"
                        required
                    >
                </label>

                <label>
                    <span>E-mail</span>
                    <input type="email" name="email" value="pablo_santos@gpssa.com.br" required>
                </label>

                <label>
                    <span>Nova senha</span>
                    <input type="password" name="senha" autocomplete="new-password" minlength="10" required>
                </label>

                <label>
                    <span>Confirmar senha</span>
                    <input type="password" name="confirmacao" autocomplete="new-password" minlength="10" required>
                </label>

                <button type="submit" class="button">Criar administrador</button>
            </form>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
