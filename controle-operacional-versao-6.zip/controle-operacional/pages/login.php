<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Core\Database;

if (Auth::check()) {
    header('Location: ' . APP_BASE_PATH . '/');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página e tente novamente.';
    } else {
        $identificador = trim((string)($_POST['identificador'] ?? ''));
        $senha = (string)($_POST['senha'] ?? '');

        try {
            if (Auth::attempt($identificador, $senha)) {
                $destination = Auth::requiresPasswordChange()
                    ? APP_BASE_PATH . '/alterar-senha'
                    : APP_BASE_PATH . '/';

                header('Location: ' . $destination);
                exit;
            }

            $error = 'E-mail ou senha inválidos.';
        } catch (Throwable $e) {
            $error = 'Banco ainda não configurado ou indisponível.';
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="auth-page">
    <section class="auth-card">
        <div class="auth-header">
            <div>
                <h1><?= htmlspecialchars(APP_NAME) ?></h1>
                <p>Acesso ao portal</p>
            </div>
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post" class="form">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

            <label>
                <span>E-mail ou usuário</span>
                <input
                    type="text"
                    name="identificador"
                    autocomplete="username"
                    autocapitalize="none"
                    spellcheck="false"
                    required
                >
            </label>

            <label>
                <span>Senha</span>
                <input type="password" name="senha" autocomplete="current-password" required>
            </label>

            <button type="submit" class="button">Entrar</button>
            <p class="auth-help">Primeiro acesso? Use o link recebido por e-mail.</p>
        </form>
    </section>
</main>
</body>
</html>
