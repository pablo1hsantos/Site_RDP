<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Helpers\UserFormatter;
use Controle\Services\UserService;

Auth::requireAdmin();

$showArchived = ($_GET['arquivados'] ?? '') === '1';
$users = UserService::list($showArchived);
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuários - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/">← Dashboard</a>
            <h1><?= $showArchived ? 'Usuários arquivados' : 'Usuários' ?></h1>
            <p class="muted">Administração de acessos do Controle Operacional.</p>
        </div>

        <div class="top-actions">
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>

            <?php if ($showArchived): ?>
                <a href="<?= APP_BASE_PATH ?>/adm/usuarios">Usuários ativos</a>
            <?php else: ?>
                <a href="<?= APP_BASE_PATH ?>/adm/usuarios?arquivados=1">Arquivados</a>
                <a class="button button-link" href="<?= APP_BASE_PATH ?>/adm/usuarios/novo">
                    Novo usuário
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Usuário</th>
                    <th>E-mail</th>
                    <th>Perfil</th>
                    <th>Status</th>
                    <th>Último login</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <?php
                    if (!empty($u['arquivado'])) {
                        $status = 'Arquivado';
                    } elseif (!(bool)$u['ativo']) {
                        $status = 'Inativo';
                    } elseif (!empty($u['primeiro_acesso_pendente'])) {
                        $status = 'Pendente';
                    } elseif (!empty($u['trocar_senha_obrigatoria'])) {
                        $status = 'Trocar senha';
                    } else {
                        $status = 'Ativo';
                    }
                ?>
                <tr>
                    <td><?= htmlspecialchars(UserFormatter::displayName($u['nome'])) ?></td>
                    <td><?= htmlspecialchars(UserFormatter::username($u['usuario'] ?? '')) ?></td>
                    <td><?= htmlspecialchars(mb_strtolower($u['email'], 'UTF-8')) ?></td>
                    <td><?= htmlspecialchars(ucfirst($u['perfil'])) ?></td>
                    <td><?= htmlspecialchars($status) ?></td>
                    <td><?= htmlspecialchars($u['ultimo_login'] ?: 'Nunca') ?></td>
                    <td class="actions">
                        <a href="<?= APP_BASE_PATH ?>/adm/usuarios/editar?id=<?= (int)$u['id'] ?>">
                            Editar
                        </a>

                        <?php if (empty($u['arquivado'])): ?>
                            <a href="<?= APP_BASE_PATH ?>/adm/usuarios/permissoes?id=<?= (int)$u['id'] ?>">
                                Permissões
                            </a>
                        <?php endif; ?>

                        <?php if (!empty($u['primeiro_acesso_pendente']) && empty($u['arquivado'])): ?>
                            <a href="<?= APP_BASE_PATH ?>/adm/usuarios/convite?id=<?= (int)$u['id'] ?>">
                                Convite
                            </a>
                        <?php endif; ?>

                        <a href="<?= APP_BASE_PATH ?>/adm/usuarios/manutencao?id=<?= (int)$u['id'] ?>">
                            Manutenção
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
