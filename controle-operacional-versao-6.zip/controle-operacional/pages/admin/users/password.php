<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;
use Controle\Helpers\UserFormatter;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        $senha = (string)($_POST['senha'] ?? '');
        $confirmacao = (string)($_POST['confirmacao'] ?? '');

        try {
            if ($senha !== $confirmacao) {
                throw new RuntimeException('As senhas não conferem.');
            }

            UserService::resetPassword($id, $senha);

            $success =
                'Senha temporária definida. As sessões foram revogadas e ' .
                'o usuário deverá trocar a senha no próximo login.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Senha temporária - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios/manutencao?id=<?= (int)$user['id'] ?>">
                ← Manutenção
            </a>
            <h1>Definir senha temporária</h1>
            <p class="muted">
                <?= htmlspecialchars(UserFormatter::displayName($user['nome'])) ?>
                · <?= htmlspecialchars($user['email']) ?>
            </p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" class="form form-card">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
        <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">

        <label>
            <span>Senha temporária</span>
            <input
                type="password"
                name="senha"
                minlength="10"
                autocomplete="new-password"
                required
            >
        </label>

        <label>
            <span>Confirmar senha</span>
            <input
                type="password"
                name="confirmacao"
                minlength="10"
                autocomplete="new-password"
                required
            >
        </label>

        <button class="button" type="submit">Definir senha temporária</button>
    </form>
</main>
</body>
</html>
