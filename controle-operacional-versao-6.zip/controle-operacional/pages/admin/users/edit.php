<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;
use Controle\Helpers\UserFormatter;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
UserService::update($id, [
                'nome' => $_POST['nome'] ?? '',
                'usuario' => $_POST['usuario'] ?? '',
                'email' => $_POST['email'] ?? '',
                'perfil' => $_POST['perfil'] ?? 'usuario',
            ]);

            $user = UserService::find($id);
            $success = 'Usuário atualizado.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar usuário - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Editar usuário</h1>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <form method="post" class="form form-card">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
        <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">

        <label>
            <span>Nome</span>
            <input type="text" name="nome" value="<?= htmlspecialchars(UserFormatter::displayName($user['nome'])) ?>" required>
        </label>

        <label>
            <span>Usuário</span>
            <input
                type="text"
                name="usuario"
                value="<?= htmlspecialchars($user['usuario'] ?? '') ?>"
                minlength="3"
                maxlength="80"
                pattern="[A-Za-z0-9._-]+"
                required
            >
            <small class="field-help">
                Login alternativo ao e-mail. Maiúsculas e minúsculas não interferem.
            </small>
        </label>

        <label>
            <span>E-mail</span>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </label>

        <label>
            <span>Perfil</span>
            <select name="perfil" required>
                <?php foreach (['usuario' => 'Usuário', 'gestor' => 'Gestor', 'administrador' => 'Administrador'] as $value => $label): ?>
                    <option value="<?= $value ?>" <?= $user['perfil'] === $value ? 'selected' : '' ?>>
                        <?= htmlspecialchars($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="check-row">
            <input type="checkbox" name="ativo" value="1" <?= (int)$user['ativo'] === 1 ? 'checked' : '' ?>>
            <span>Usuário ativo</span>
        </label>

        <button class="button" type="submit">Salvar alterações</button>
    </form>
</main>
</body>
</html>
