<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\AdminLogService;
use Controle\Services\UserService;
use Controle\Helpers\UserFormatter;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        $action = (string)($_POST['acao'] ?? '');
        $reason = trim((string)($_POST['motivo'] ?? ''));

        try {
            switch ($action) {
                case 'desativar':
                    UserService::setActive($id, false, $reason);
                    $success = 'Usuário desativado e sessões existentes invalidadas.';
                    break;

                case 'reativar':
                    UserService::setActive($id, true);
                    $success = 'Usuário reativado.';
                    break;

                case 'revogar_sessoes':
                    UserService::revokeSessions($id);
                    $success = 'Todas as sessões do usuário foram revogadas.';
                    break;

                case 'forcar_troca_senha':
                    UserService::forcePasswordChange($id);
                    $success = 'Troca de senha obrigatória ativada e sessões revogadas.';
                    break;

                case 'arquivar':
                    UserService::archive($id, $reason);
                    $success = 'Usuário arquivado.';
                    break;

                case 'desarquivar':
                    UserService::unarchive($id);
                    $success = 'Usuário desarquivado. Ele permanece inativo.';
                    break;

                default:
                    throw new RuntimeException('Ação inválida.');
            }

            $user = UserService::find($id);
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$logs = AdminLogService::recentForUser($id);
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
$isSelf = $id === (int)(Auth::user()['id'] ?? 0);

if (!empty($user['arquivado'])) {
    $status = 'Arquivado';
} elseif (!(bool)$user['ativo']) {
    $status = 'Inativo';
} elseif (!empty($user['primeiro_acesso_pendente'])) {
    $status = 'Pendente';
} else {
    $status = 'Ativo';
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manutenção de usuário - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Manutenção de usuário</h1>
            <p class="muted">
                <?= htmlspecialchars(UserFormatter::displayName($user['nome'])) ?>
                · <?= htmlspecialchars($user['email']) ?>
            </p>
        </div>
        <div class="top-actions">
            <span class="status-badge"><?= htmlspecialchars($status) ?></span>
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($isSelf): ?>
        <div class="alert">
            Ações críticas sobre o próprio administrador ficam bloqueadas nesta tela.
            Use "Alterar senha" para sua própria conta.
        </div>
    <?php endif; ?>

    <div class="maintenance-grid">
        <section class="form-card">
            <h2>Acesso</h2>

            <?php if (!empty($user['arquivado'])): ?>
                <p class="muted">Usuário arquivado não pode acessar o sistema.</p>

                <form method="post">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="desarquivar">
                    <button class="button" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Desarquivar
                    </button>
                </form>

            <?php elseif ((bool)$user['ativo']): ?>
                <p class="muted">
                    Desativar bloqueia novos acessos e derruba as sessões existentes.
                </p>

                <form method="post" class="form">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="desativar">

                    <label>
                        <span>Motivo opcional</span>
                        <textarea name="motivo" rows="3" maxlength="255"></textarea>
                    </label>

                    <button class="button button-danger" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Desativar usuário
                    </button>
                </form>

            <?php else: ?>
                <p class="muted">
                    Usuário está inativo.
                    <?= !empty($user['motivo_desativacao'])
                        ? 'Motivo: ' . htmlspecialchars($user['motivo_desativacao'])
                        : '' ?>
                </p>

                <form method="post">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="reativar">
                    <button class="button" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Reativar usuário
                    </button>
                </form>
            <?php endif; ?>
        </section>

        <section class="form-card">
            <h2>Sessões e senha</h2>

            <div class="stack-actions">
                <form method="post">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="revogar_sessoes">
                    <button class="button button-secondary" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Revogar todas as sessões
                    </button>
                </form>

                <form method="post">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="forcar_troca_senha">
                    <button class="button button-secondary" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Forçar troca de senha
                    </button>
                </form>

                <?php if (!$isSelf && empty($user['arquivado'])): ?>
                    <a
                        class="button button-link button-secondary"
                        href="<?= APP_BASE_PATH ?>/adm/usuarios/senha?id=<?= (int)$user['id'] ?>"
                    >
                        Definir senha temporária
                    </a>
                <?php endif; ?>
            </div>

            <?php if (!empty($user['trocar_senha_obrigatoria'])): ?>
                <p class="notice">Troca obrigatória de senha está ativa.</p>
            <?php endif; ?>
        </section>

        <section class="form-card maintenance-danger">
            <h2>Arquivamento</h2>
            <p class="muted">
                Arquivar retira o usuário da lista normal, bloqueia acesso e preserva histórico.
            </p>

            <?php if (empty($user['arquivado'])): ?>
                <form method="post" class="form">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
                    <input type="hidden" name="acao" value="arquivar">

                    <label>
                        <span>Motivo opcional</span>
                        <textarea name="motivo" rows="3" maxlength="255"></textarea>
                    </label>

                    <button class="button button-danger" type="submit" <?= $isSelf ? 'disabled' : '' ?>>
                        Arquivar usuário
                    </button>
                </form>
            <?php else: ?>
                <p class="muted">
                    Arquivado em:
                    <?= htmlspecialchars((string)($user['arquivado_em'] ?? '')) ?>
                </p>
            <?php endif; ?>
        </section>
    </div>

    <section class="section-block">
        <h2>Histórico administrativo</h2>

        <?php if (!$logs): ?>
            <p class="muted">Nenhuma ação administrativa registrada.</p>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Ação</th>
                            <th>Administrador</th>
                            <th>Detalhes</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['criado_em']) ?></td>
                            <td><?= htmlspecialchars($log['acao']) ?></td>
                            <td><?= htmlspecialchars($log['administrador_nome']) ?></td>
                            <td><?= htmlspecialchars($log['detalhes'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
