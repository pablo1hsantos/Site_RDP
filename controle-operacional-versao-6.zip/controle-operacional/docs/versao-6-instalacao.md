# Controle Operacional - Versão 6

## Objetivo
Manutenção segura de usuários sem exclusão definitiva de histórico.

## Recursos
- Desativar usuário
- Reativar usuário
- Revogar todas as sessões
- Forçar troca de senha no próximo login
- Alteração da própria senha
- Definição administrativa de senha temporária
- Arquivar usuário
- Desarquivar usuário
- Histórico administrativo de manutenção
- Motivo opcional para desativação e arquivamento

## Comportamento de segurança

### Desativar
Ao desativar:
- novos logins são bloqueados;
- sessões existentes são invalidadas;
- data da desativação é registrada;
- motivo opcional é registrado.

### Revogar sessões
Incrementa a versão de autenticação do usuário.
No próximo acesso, qualquer sessão antiga deixa de ser válida.

### Forçar troca de senha
- sessões atuais são revogadas;
- usuário entra novamente com a senha atual;
- é redirecionado obrigatoriamente para `/alterar-senha`;
- só depois consegue acessar os módulos.

### Senha temporária
O administrador pode definir uma senha temporária.
O usuário é obrigado a trocá-la no próximo login.

### Arquivar
Arquivamento:
- bloqueia o acesso;
- revoga sessões;
- retira o usuário da lista normal;
- mantém histórico e permissões no banco;
- não apaga registros.

Arquivados podem ser consultados em:

`/adm/usuarios?arquivados=1`

## Atualização do banco

Primeiro no QA:

`https://portalrdp.online/qa/adm/atualizar`

Depois de validar:

`https://portalrdp.online/adm/atualizar`

Clique em `Aplicar atualização`.

## Teste recomendado em QA

1. Aplicar a Versão 6 em `/qa/adm/atualizar`.
2. Criar ou escolher um usuário de teste.
3. Acessar `/qa/adm/usuarios/manutencao?id=ID`.
4. Fazer login com o usuário de teste em janela anônima.
5. Revogar as sessões pelo administrador.
6. Atualizar a janela do usuário e confirmar retorno ao login.
7. Forçar troca de senha.
8. Entrar novamente e confirmar redirecionamento para `/qa/alterar-senha`.
9. Alterar a senha.
10. Desativar e confirmar bloqueio.
11. Reativar e confirmar novo acesso.
12. Arquivar e confirmar que desaparece da lista normal.

## Configurações sensíveis

O ZIP continua sem:
- `config/database.php`
- `config/mail.php`

Esses arquivos permanecem no servidor.


## Complemento da Versão 6 - Padronização de usuário

### Login
Cada conta passa a ter:
- Nome
- Usuário
- E-mail

Exemplo:

`PABLO SANTOS`

Usuário:

`pablo_santos`

E-mail:

`pablo_santos@gpssa.com.br`

O login aceita tanto:

`pablo_santos`

quanto:

`pablo_santos@gpssa.com.br`

Maiúsculas e minúsculas não interferem no login.

### Usuários já existentes
Ao aplicar `/adm/atualizar`, o sistema cria automaticamente o usuário técnico
usando inicialmente a parte do e-mail anterior ao `@`.

Exemplo:

`pablo_santos@gpssa.com.br`

vira:

`pablo_santos`

Se houver duplicidade, o sistema acrescenta um número automaticamente.

### Exibição
O nome humano é sempre exibido em caixa alta no painel:

`PABLO SANTOS`

O nome de usuário técnico permanece normalizado em letras minúsculas:

`pablo_santos`


### Durante a atualização
O login por e-mail continua funcionando mesmo antes de aplicar novamente
`/adm/atualizar`. Depois da atualização do banco, o login por nome de usuário
também passa a funcionar.
