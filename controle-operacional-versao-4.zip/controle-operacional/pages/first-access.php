<?php
declare(strict_types=1);

use Controle\Core\Csrf;
use Controle\Services\UserService;

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        $email = trim((string)($_POST['email'] ?? ''));
        $codigo = trim((string)($_POST['codigo'] ?? ''));
        $senha = (string)($_POST['senha'] ?? '');
        $confirmacao = (string)($_POST['confirmacao'] ?? '');

        try {
            if ($senha !== $confirmacao) {
                throw new RuntimeException('As senhas não conferem.');
            }

            UserService::activate($email, $codigo, $senha);
            $success = 'Senha criada. Seu acesso está ativo.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Primeiro acesso - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="auth-page">
    <section class="auth-card">
        <div class="auth-header">
            <div>
                <h1>Primeiro acesso</h1>
                <p>Crie sua senha do Controle Operacional.</p>
            </div>
            <span class="env"><?= htmlspecialchars($envLabel) ?></span>
        </div>

        <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <a class="button button-link" href="<?= APP_BASE_PATH ?>/login">Ir para o login</a>
        <?php else: ?>
            <form method="post" class="form">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

                <label>
                    <span>E-mail</span>
                    <input type="email" name="email" autocomplete="username" required>
                </label>

                <label>
                    <span>Código de ativação</span>
                    <input type="text" name="codigo" placeholder="ABCD-2345" maxlength="9" required>
                </label>

                <label>
                    <span>Nova senha</span>
                    <input type="password" name="senha" minlength="10" autocomplete="new-password" required>
                </label>

                <label>
                    <span>Confirmar senha</span>
                    <input type="password" name="confirmacao" minlength="10" autocomplete="new-password" required>
                </label>

                <button type="submit" class="button">Ativar meu acesso</button>
            </form>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
