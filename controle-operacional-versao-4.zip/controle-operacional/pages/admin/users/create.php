<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$error = null;
$created = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
            $created = UserService::createPending([
                'nome' => $_POST['nome'] ?? '',
                'email' => $_POST['email'] ?? '',
                'perfil' => $_POST['perfil'] ?? 'usuario',
                'ativo' => isset($_POST['ativo']),
            ]);
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Novo usuário - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Novo usuário</h1>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($created): ?>
        <div class="alert alert-success">
            Usuário criado. Entregue o código abaixo ao usuário. Ele expira em 72 horas.
        </div>

        <div class="activation-box">
            <span>Código de primeiro acesso</span>
            <strong><?= htmlspecialchars($created['code']) ?></strong>
        </div>

        <div class="form-actions actions">
            <a class="button button-link" href="<?= APP_BASE_PATH ?>/adm/usuarios/permissoes?id=<?= (int)$created['id'] ?>">
                Configurar permissões
            </a>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">Voltar aos usuários</a>
        </div>
    <?php else: ?>
        <form method="post" class="form form-card">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

            <label>
                <span>Nome</span>
                <input type="text" name="nome" value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
            </label>

            <label>
                <span>E-mail</span>
                <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </label>

            <label>
                <span>Perfil</span>
                <select name="perfil" required>
                    <option value="usuario">Usuário</option>
                    <option value="gestor">Gestor</option>
                    <option value="administrador">Administrador</option>
                </select>
            </label>

            <label class="check-row">
                <input type="checkbox" name="ativo" value="1" checked>
                <span>Usuário ativo</span>
            </label>

            <button class="button" type="submit">Criar usuário e gerar código</button>
        </form>
    <?php endif; ?>
</main>
</body>
</html>
