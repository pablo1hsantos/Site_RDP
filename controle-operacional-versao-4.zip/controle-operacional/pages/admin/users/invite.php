<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$user = UserService::find($id);

if (!$user) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}

$error = null;
$code = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
            $code = UserService::regenerateActivationCode($id);
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Código de acesso - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Código de primeiro acesso</h1>
            <p class="muted"><?= htmlspecialchars($user['nome']) ?> · <?= htmlspecialchars($user['email']) ?></p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if ($code): ?>
        <div class="alert alert-success">Novo código gerado. Ele expira em 72 horas.</div>
        <div class="activation-box">
            <span>Código de primeiro acesso</span>
            <strong><?= htmlspecialchars($code) ?></strong>
        </div>
    <?php elseif (!empty($user['primeiro_acesso_pendente'])): ?>
        <form method="post" class="form-card">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">
            <p>O código atual não pode ser recuperado, apenas substituído.</p>
            <button type="submit" class="button">Gerar novo código</button>
        </form>
    <?php else: ?>
        <div class="alert">Este usuário já concluiu o primeiro acesso.</div>
    <?php endif; ?>
</main>
</body>
</html>
