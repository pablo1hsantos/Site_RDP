<?php
declare(strict_types=1);

namespace Controle\Services;

use Controle\Core\Database;
use InvalidArgumentException;
use PDOException;

final class UserService
{
    public static function list(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT *
             FROM usuarios
             ORDER BY nome'
        )->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM usuarios
             WHERE id = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $id]);

        $user = $stmt->fetch();

        return $user ?: null;
    }

    public static function createPending(array $data): array
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');

        self::validateBase($nome, $email, $perfil);

        $code = self::generateActivationCode();
        $temporaryPassword = bin2hex(random_bytes(32));

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO usuarios
                (
                    nome, email, senha_hash, perfil, ativo,
                    primeiro_acesso_pendente,
                    codigo_ativacao_hash,
                    codigo_ativacao_expira,
                    criado_em, atualizado_em
                )
                VALUES
                (
                    :nome, :email, :senha_hash, :perfil, :ativo,
                    1,
                    :codigo_hash,
                    DATE_ADD(NOW(), INTERVAL 72 HOUR),
                    NOW(), NOW()
                )'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'senha_hash' => password_hash($temporaryPassword, PASSWORD_DEFAULT),
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'codigo_hash' => password_hash($code, PASSWORD_DEFAULT),
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }

        return [
            'id' => (int)$pdo->lastInsertId(),
            'code' => $code,
        ];
    }

    public static function regenerateActivationCode(int $id): string
    {
        $user = self::find($id);

        if (!$user) {
            throw new InvalidArgumentException('Usuário não encontrado.');
        }

        if (!(bool)$user['primeiro_acesso_pendente']) {
            throw new InvalidArgumentException('Este usuário já concluiu o primeiro acesso.');
        }

        $code = self::generateActivationCode();
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET codigo_ativacao_hash = :codigo_hash,
                 codigo_ativacao_expira = DATE_ADD(NOW(), INTERVAL 72 HOUR),
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'codigo_hash' => password_hash($code, PASSWORD_DEFAULT),
            'id' => $id,
        ]);

        return $code;
    }

    public static function activate(string $email, string $code, string $password): void
    {
        $email = mb_strtolower(trim($email));
        $code = strtoupper(trim($code));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Informe um e-mail válido.');
        }

        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT id, ativo, primeiro_acesso_pendente,
                    codigo_ativacao_hash, codigo_ativacao_expira
             FROM usuarios
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !(bool)$user['ativo']) {
            throw new InvalidArgumentException('Convite inválido ou usuário indisponível.');
        }

        if (!(bool)$user['primeiro_acesso_pendente']) {
            throw new InvalidArgumentException('O primeiro acesso deste usuário já foi concluído.');
        }

        if (empty($user['codigo_ativacao_hash']) || empty($user['codigo_ativacao_expira'])) {
            throw new InvalidArgumentException('Código de ativação indisponível.');
        }

        if (strtotime((string)$user['codigo_ativacao_expira']) < time()) {
            throw new InvalidArgumentException('O código expirou. Solicite um novo código ao administrador.');
        }

        if (!password_verify($code, (string)$user['codigo_ativacao_hash'])) {
            throw new InvalidArgumentException('E-mail ou código de ativação inválido.');
        }

        $up = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :senha_hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $up->execute([
            'senha_hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $user['id'],
        ]);
    }

    public static function update(int $id, array $data): void
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');

        self::validateBase($nome, $email, $perfil);

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'UPDATE usuarios
                 SET nome = :nome,
                     email = :email,
                     perfil = :perfil,
                     ativo = :ativo,
                     atualizado_em = NOW()
                 WHERE id = :id'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'id' => $id,
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }
    }

    public static function resetPassword(int $id, string $password): void
    {
        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :hash,
                 primeiro_acesso_pendente = 0,
                 codigo_ativacao_hash = NULL,
                 codigo_ativacao_expira = NULL,
                 atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $id,
        ]);
    }

    public static function modules(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT id, codigo, nome
             FROM modulos
             WHERE ativo = 1
             ORDER BY nome'
        )->fetchAll();
    }

    public static function permissions(int $userId): array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT modulo_id, visualizar, criar, editar, excluir, administrar
             FROM permissoes_usuario
             WHERE usuario_id = :usuario_id'
        );
        $stmt->execute(['usuario_id' => $userId]);

        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['modulo_id']] = $row;
        }

        return $out;
    }

    public static function savePermissions(int $userId, array $permissions): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $del = $pdo->prepare('DELETE FROM permissoes_usuario WHERE usuario_id = :usuario_id');
            $del->execute(['usuario_id' => $userId]);

            $ins = $pdo->prepare(
                'INSERT INTO permissoes_usuario
                (usuario_id, modulo_id, visualizar, criar, editar, excluir, administrar)
                VALUES
                (:usuario_id, :modulo_id, :visualizar, :criar, :editar, :excluir, :administrar)'
            );

            foreach ($permissions as $moduleId => $row) {
                $moduleId = (int)$moduleId;
                if ($moduleId <= 0) {
                    continue;
                }

                $ins->execute([
                    'usuario_id' => $userId,
                    'modulo_id' => $moduleId,
                    'visualizar' => !empty($row['visualizar']) ? 1 : 0,
                    'criar' => !empty($row['criar']) ? 1 : 0,
                    'editar' => !empty($row['editar']) ? 1 : 0,
                    'excluir' => !empty($row['excluir']) ? 1 : 0,
                    'administrar' => !empty($row['administrar']) ? 1 : 0,
                ]);
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function validateBase(string $nome, string $email, string $perfil): void
    {
        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do usuário.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Informe um e-mail válido.');
        }

        if (!in_array($perfil, ['administrador', 'gestor', 'usuario'], true)) {
            throw new InvalidArgumentException('Perfil inválido.');
        }
    }

    private static function generateActivationCode(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

        $block = function () use ($alphabet): string {
            $out = '';
            for ($i = 0; $i < 4; $i++) {
                $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            return $out;
        };

        return $block() . '-' . $block();
    }
}
