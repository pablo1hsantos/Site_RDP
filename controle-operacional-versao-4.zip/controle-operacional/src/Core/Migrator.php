<?php
declare(strict_types=1);

namespace Controle\Core;

use PDO;

final class Migrator
{
    public static function runV4(): void
    {
        $pdo = Database::connection();

        $columns = [
            'primeiro_acesso_pendente' => "
                ALTER TABLE usuarios
                ADD COLUMN primeiro_acesso_pendente TINYINT(1) NOT NULL DEFAULT 0 AFTER ativo
            ",
            'codigo_ativacao_hash' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_hash VARCHAR(255) NULL AFTER primeiro_acesso_pendente
            ",
            'codigo_ativacao_expira' => "
                ALTER TABLE usuarios
                ADD COLUMN codigo_ativacao_expira DATETIME NULL AFTER codigo_ativacao_hash
            ",
        ];

        foreach ($columns as $column => $sql) {
            if (!self::columnExists($pdo, 'usuarios', $column)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = :table_name
               AND COLUMN_NAME = :column_name'
        );

        $stmt->execute([
            'table_name' => $table,
            'column_name' => $column,
        ]);

        return (int)$stmt->fetchColumn() > 0;
    }
}
