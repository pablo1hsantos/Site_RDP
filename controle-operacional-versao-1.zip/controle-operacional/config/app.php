<?php
declare(strict_types=1);

return [
    'name' => 'Controle Operacional',
    'domain' => 'portalrdp.online',
    'timezone' => 'America/Sao_Paulo',

    /*
     * Etapa 1:
     * - PROD: https://portalrdp.online/
     * - QA:   https://portalrdp.online/qa/
     *
     * Ambiente confirmado na HostGator: PHP 8.4.24.
     * Os IDs do Google e demais credenciais entram em etapas posteriores.
     */
];
