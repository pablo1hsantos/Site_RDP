<?php
declare(strict_types=1);

$base = APP_BASE_PATH;
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';

$modules = [
    ['label' => 'Compras', 'url' => '/compras'],
    ['label' => 'Organograma', 'url' => '/organograma'],
    ['label' => 'Justificativa HE', 'url' => '/justificativa-he'],
    ['label' => 'Pagamentos', 'url' => '/pagamentos'],
    ['label' => 'Solicitações', 'url' => '/solicitacoes'],
    ['label' => 'Plano de Ação', 'url' => '/plano-de-acao'],
    ['label' => 'Atividades', 'url' => '/atividades'],
    ['label' => 'ADM · Compras', 'url' => '/adm/compras'],
    ['label' => 'ADM · Organograma', 'url' => '/adm/organograma'],
    ['label' => 'ADM · Solicitações', 'url' => '/adm/solicitacoes'],
];
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= $base ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <h1><?= htmlspecialchars(APP_NAME) ?></h1>
            <p class="muted">Fundação inicial do portal modular.</p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <div class="grid">
        <?php foreach ($modules as $module): ?>
            <a class="card" href="<?= $base . $module['url'] ?>">
                <strong><?= htmlspecialchars($module['label']) ?></strong>
            </a>
        <?php endforeach; ?>
    </div>
</main>
<script src="<?= $base ?>/assets/js/app.js"></script>
</body>
</html>
