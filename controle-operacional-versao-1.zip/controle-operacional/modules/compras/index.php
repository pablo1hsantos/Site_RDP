<?php
declare(strict_types=1);

$base = APP_BASE_PATH;
$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Compras - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= $base ?>/assets/css/app.css">
</head>
<body>
<main class="page">
    <div class="topbar">
        <div>
            <a href="<?= $base ?>/">← Dashboard</a>
            <h1>Compras</h1>
            <p class="muted">Módulo reservado. Funcionalidades entram nas próximas etapas.</p>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>
</main>
</body>
</html>
