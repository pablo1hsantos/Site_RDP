<?php
declare(strict_types=1);

namespace Controle\Core;

final class Router
{
    public function __construct(
        private string $environment,
        private string $basePath = ''
    ) {
    }

    public function dispatch(): void
    {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

        if ($this->basePath !== '' && str_starts_with($path, $this->basePath)) {
            $path = substr($path, strlen($this->basePath));
        }

        $path = '/' . trim($path, '/');

        if ($path === '/') {
            $this->renderModule('dashboard');
            return;
        }

        $routes = [
            '/dashboard' => 'dashboard',
            '/compras' => 'compras',
            '/organograma' => 'organograma',
            '/justificativa-he' => 'justificativa-he',
            '/pagamentos' => 'pagamentos',
            '/solicitacoes' => 'solicitacoes',
            '/plano-de-acao' => 'plano-de-acao',
            '/atividades' => 'atividades',
            '/adm/compras' => 'adm/compras',
            '/adm/organograma' => 'adm/organograma',
            '/adm/solicitacoes' => 'adm/solicitacoes',
        ];

        if (!isset($routes[$path])) {
            http_response_code(404);
            $this->renderSimplePage('Página não encontrada', 'A rota solicitada ainda não existe.');
            return;
        }

        $this->renderModule($routes[$path]);
    }

    private function renderModule(string $module): void
    {
        $moduleFile = APP_ROOT . '/modules/' . $module . '/index.php';

        if (!is_file($moduleFile)) {
            http_response_code(500);
            $this->renderSimplePage('Módulo indisponível', 'O arquivo do módulo não foi encontrado.');
            return;
        }

        require $moduleFile;
    }

    private function renderSimplePage(string $title, string $message): void
    {
        $envLabel = $this->environment === 'qa' ? 'QA' : 'PROD';

        echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">';
        echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>' . htmlspecialchars($title) . ' - ' . htmlspecialchars(APP_NAME) . '</title>';
        echo '<link rel="stylesheet" href="' . $this->basePath . '/assets/css/app.css">';
        echo '</head><body><main class="page">';
        echo '<span class="env">' . htmlspecialchars($envLabel) . '</span>';
        echo '<h1>' . htmlspecialchars($title) . '</h1>';
        echo '<p>' . htmlspecialchars($message) . '</p>';
        echo '</main></body></html>';
    }
}
