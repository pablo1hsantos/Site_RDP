<?php
declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'Controle\\';
    $baseDir = dirname(__DIR__) . '/';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relativeClass = substr($class, strlen($prefix));
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (is_file($file)) {
        require $file;
    }
});

$config = require dirname(__DIR__, 2) . '/config/app.php';

$uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

$isQa = $uriPath === '/qa' || str_starts_with($uriPath, '/qa/');
$env = $isQa ? 'qa' : 'production';
$basePath = $isQa ? '/qa' : '';

define('APP_NAME', $config['name']);
define('APP_ENV', $env);
define('APP_BASE_PATH', $basePath);
define('APP_ROOT', dirname(__DIR__, 2));

date_default_timezone_set($config['timezone']);
