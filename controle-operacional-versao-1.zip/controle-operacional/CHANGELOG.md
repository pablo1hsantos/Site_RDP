# Changelog

## 0.1.3 - Ajuste de deploy
- Confirmado `/public_html` como pasta de publicação
- Removidas suposições sobre outros conteúdos existentes no servidor
- Documentação de primeiro upload simplificada

## 0.1.2 - Preparação para primeiro deploy
- Corrigido carregamento de CSS/JS no ambiente lógico `/qa/`
- Preparação das rotas para primeiro deploy

## 0.1.1 - Ambiente confirmado
- PHP da HostGator confirmado em 8.4.24
- Fluxo inicial sem GitHub
- Versionamento por pacotes ZIP
- Checklist para primeiro upload na HostGator

## 0.1.0 - Fundação
- Estrutura modular inicial
- Roteamento PROD e QA
- Dashboard provisório
- Módulos reservados
- Configuração base
- Documentação inicial
