# Controle Operacional

Fundação inicial para o portal modular `portalrdp.online`.

## Ambientes
- PROD: `https://portalrdp.online/`
- QA: `https://portalrdp.online/qa/`

## Requisitos iniciais
- PHP 8.4.24
- Apache com `mod_rewrite`

## Módulos
- Compras
- Organograma
- Justificativa HE
- Pagamentos
- Solicitações
- Plano de Ação
- Atividades
- ADM / Compras
- ADM / Organograma
- ADM / Solicitações

## Importante
A pasta `/qa/` é uma rota lógica, não uma cópia física do sistema.
Isso evita manter duas versões de código diferentes.

## Fluxo de trabalho inicial
- Desenvolvimento e montagem do projeto aqui no ChatGPT
- Entrega por pacotes `.zip`
- Upload manual para a HostGator
- Controle de versões por pacotes numerados e `CHANGELOG.md`
- GitHub não é obrigatório nesta fase

## Ainda não implementado
- login
- sessões
- permissões
- Google Sheets
- Google Drive
- logs
- APIs de negócio
