# Changelog

## Versão 3 - Usuários e permissões
- Tela administrativa de usuários
- Criação e edição de usuários
- Ativação e desativação
- Redefinição administrativa de senha
- Perfis Administrador, Gestor e Usuário
- Permissões individuais por módulo
- Permissões: visualizar, criar, editar, excluir e administrar
- Administrador com acesso total automático
- Dashboard mostra apenas módulos permitidos
- Proteção das rotas administrativas
- `config/database.php` deixa de ser incluído nos ZIPs de atualização
- Adicionado `config/database.example.php`
- Migração não destrutiva registrada

## Versão 2 - Autenticação e banco
- Login por e-mail e senha
- Sessão PHP segura
- Logout
- Setup inicial de administrador
- Bancos separados para PROD e QA
- Estrutura de perfis e permissões

## Versão 1 - Fundação
- Estrutura modular inicial
- Roteamento PROD e QA
- Dashboard provisório
- Módulos reservados
