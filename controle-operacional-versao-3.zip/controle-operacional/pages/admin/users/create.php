<?php
declare(strict_types=1);

use Controle\Auth\Auth;
use Controle\Core\Csrf;
use Controle\Services\UserService;

Auth::requireAdmin();

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate($_POST['_csrf'] ?? null)) {
        $error = 'Sessão expirada. Atualize a página.';
    } else {
        try {
            $id = UserService::create([
                'nome' => $_POST['nome'] ?? '',
                'email' => $_POST['email'] ?? '',
                'perfil' => $_POST['perfil'] ?? 'usuario',
                'senha' => $_POST['senha'] ?? '',
                'ativo' => isset($_POST['ativo']),
            ]);

            header('Location: ' . APP_BASE_PATH . '/adm/usuarios/permissoes?id=' . $id);
            exit;
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$envLabel = APP_ENV === 'qa' ? 'QA' : 'PROD';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Novo usuário - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_BASE_PATH ?>/assets/css/app.css">
</head>
<body>
<main class="page form-page">
    <div class="topbar">
        <div>
            <a href="<?= APP_BASE_PATH ?>/adm/usuarios">← Usuários</a>
            <h1>Novo usuário</h1>
        </div>
        <span class="env"><?= htmlspecialchars($envLabel) ?></span>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form form-card">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token()) ?>">

        <label>
            <span>Nome</span>
            <input type="text" name="nome" value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
        </label>

        <label>
            <span>E-mail</span>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </label>

        <label>
            <span>Perfil</span>
            <select name="perfil" required>
                <option value="usuario">Usuário</option>
                <option value="gestor">Gestor</option>
                <option value="administrador">Administrador</option>
            </select>
        </label>

        <label>
            <span>Senha inicial</span>
            <input type="password" name="senha" minlength="10" autocomplete="new-password" required>
        </label>

        <label class="check-row">
            <input type="checkbox" name="ativo" value="1" checked>
            <span>Usuário ativo</span>
        </label>

        <button class="button" type="submit">Criar usuário</button>
    </form>
</main>
</body>
</html>
