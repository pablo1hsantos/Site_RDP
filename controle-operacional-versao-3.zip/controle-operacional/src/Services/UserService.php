<?php
declare(strict_types=1);

namespace Controle\Services;

use Controle\Core\Database;
use InvalidArgumentException;
use PDOException;

final class UserService
{
    public static function list(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT id, nome, email, perfil, ativo, ultimo_login, criado_em
             FROM usuarios
             ORDER BY nome'
        )->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT id, nome, email, perfil, ativo, ultimo_login, criado_em, atualizado_em
             FROM usuarios
             WHERE id = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $id]);

        $user = $stmt->fetch();

        return $user ?: null;
    }

    public static function create(array $data): int
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');
        $senha = (string)($data['senha'] ?? '');

        self::validateBase($nome, $email, $perfil);

        if (strlen($senha) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO usuarios
                (nome, email, senha_hash, perfil, ativo, criado_em, atualizado_em)
                VALUES
                (:nome, :email, :senha_hash, :perfil, :ativo, NOW(), NOW())'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'senha_hash' => password_hash($senha, PASSWORD_DEFAULT),
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }

        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $nome = trim((string)($data['nome'] ?? ''));
        $email = mb_strtolower(trim((string)($data['email'] ?? '')));
        $perfil = (string)($data['perfil'] ?? 'usuario');

        self::validateBase($nome, $email, $perfil);

        $pdo = Database::connection();

        try {
            $stmt = $pdo->prepare(
                'UPDATE usuarios
                 SET nome = :nome,
                     email = :email,
                     perfil = :perfil,
                     ativo = :ativo,
                     atualizado_em = NOW()
                 WHERE id = :id'
            );

            $stmt->execute([
                'nome' => $nome,
                'email' => $email,
                'perfil' => $perfil,
                'ativo' => !empty($data['ativo']) ? 1 : 0,
                'id' => $id,
            ]);
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) === 1062) {
                throw new InvalidArgumentException('Já existe um usuário com este e-mail.');
            }
            throw $e;
        }
    }

    public static function resetPassword(int $id, string $password): void
    {
        if (strlen($password) < 10) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 10 caracteres.');
        }

        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'UPDATE usuarios
             SET senha_hash = :hash, atualizado_em = NOW()
             WHERE id = :id'
        );

        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'id' => $id,
        ]);
    }

    public static function modules(): array
    {
        $pdo = Database::connection();

        return $pdo->query(
            'SELECT id, codigo, nome
             FROM modulos
             WHERE ativo = 1
             ORDER BY nome'
        )->fetchAll();
    }

    public static function permissions(int $userId): array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare(
            'SELECT modulo_id, visualizar, criar, editar, excluir, administrar
             FROM permissoes_usuario
             WHERE usuario_id = :usuario_id'
        );
        $stmt->execute(['usuario_id' => $userId]);

        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['modulo_id']] = $row;
        }

        return $out;
    }

    public static function savePermissions(int $userId, array $permissions): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $del = $pdo->prepare('DELETE FROM permissoes_usuario WHERE usuario_id = :usuario_id');
            $del->execute(['usuario_id' => $userId]);

            $ins = $pdo->prepare(
                'INSERT INTO permissoes_usuario
                (usuario_id, modulo_id, visualizar, criar, editar, excluir, administrar)
                VALUES
                (:usuario_id, :modulo_id, :visualizar, :criar, :editar, :excluir, :administrar)'
            );

            foreach ($permissions as $moduleId => $row) {
                $moduleId = (int)$moduleId;
                if ($moduleId <= 0) {
                    continue;
                }

                $ins->execute([
                    'usuario_id' => $userId,
                    'modulo_id' => $moduleId,
                    'visualizar' => !empty($row['visualizar']) ? 1 : 0,
                    'criar' => !empty($row['criar']) ? 1 : 0,
                    'editar' => !empty($row['editar']) ? 1 : 0,
                    'excluir' => !empty($row['excluir']) ? 1 : 0,
                    'administrar' => !empty($row['administrar']) ? 1 : 0,
                ]);
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function validateBase(string $nome, string $email, string $perfil): void
    {
        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do usuário.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Informe um e-mail válido.');
        }

        if (!in_array($perfil, ['administrador', 'gestor', 'usuario'], true)) {
            throw new InvalidArgumentException('Perfil inválido.');
        }
    }
}
