# Controle Operacional

Portal modular hospedado em `portalrdp.online`.

## Ambiente
- PHP: 8.4.24
- PROD: `https://portalrdp.online/`
- QA: `https://portalrdp.online/qa/`

## Versão atual
Versão 3

## Recursos
- Login por e-mail e senha
- Sessão PHP
- Usuários e perfis
- Permissões individuais por módulo
- Ambientes PROD e QA separados

## Credenciais do banco
O arquivo `config/database.php` deve permanecer somente no servidor.

Pacotes de atualização incluem apenas:

`config/database.example.php`

## Instalação / atualização
Leia:

`docs/versao-3-instalacao.md`
